# TTM T5 — Phán quyết thiết kế xác minh kép chủ sở hữu TCP và HTTP

**Ngày:** 2026-11-09  
**Nhãn:** `TTM_T5_FROZEN_REPLAY_SAFE_OWNER_HTTP_DUAL_ATTESTATION_RELEASE_DESIGN_AND_OFFLINE_QA`  
**Nhánh:** `research/ttm-small-4m-colab-pilot-prereg-20261108` (PR #12, DRAFT)  
**Trạng thái:** `PASS_SCOPED_OFFLINE_SOURCE_QA_114_OF_114` · `NATIVE_WINDOWS_QA=NOT_EXECUTED` · `RUNTIME_PERMIT=NOT_ISSUED`.

## 1. Bằng chứng nguồn đã khóa

- V1, V2 và V3 RC1 **đã tiêu thụ**, không được chạy lại, xóa claim hay sửa báo cáo gốc.
- RC1 Windows QA 84/84 PASS nhưng thực thi thật bị HOLD tại TCP `State=""` (CIM `State=0`), trước HTTP/create/generate.
- IP Helper `GetExtendedTcpTable` trên Ollama hiện có cổng 11434: IPv4 `0.0.0.0` và IPv6 `::`, cùng PID 14464, cả hai `state_code=0`, API_SUCCESS. HTTP 200/version 0.40.14 của dịch vụ tồn tại và ảnh GUI có phản hồi, nhưng đó **không phải TTM-Small-4M**.
- MIB TCP `LISTEN=2`. Không phép nào trong bộ nguồn này đổi `0` thành `2` hoặc khẳng định một socket chưa xác minh có trạng thái LISTEN.
- Giữ nguyên GGUF F32 SHA-256 `5bdc904e6c51af04a4223219f36e6bc2e687f60fd6e17dc24508f3eb7489e4e5`; T5 strict full-logits parity **FAIL 7/8**.

## 2. Thiết kế kỹ thuật đã triển khai

1. **Phân lập đầy đủ**: ứng viên nguồn V4/dual RC2, cổng `127.0.0.1:12646`, model tag `ttm-t5-f32-compat-only-dual-rc2:latest`, root model/evidence mới bên trong `D:\WORK\RESEARCH\TokenToModel-Lab\_tmp`. V1/V2/RC1 không thay đổi. Gọi cả IPv4/IPv6; lỗi của bất kỳ họ địa chỉ nào là HOLD.
2. **Dữ liệu TCP gốc**: IP Helper native, bảng `TCP_TABLE_OWNER_PID_ALL`, giới hạn độ dài buffer/count, trường PID, địa chỉ cục bộ, đầu xa, cổng, trạng thái dạng số. `state=0` là `UNKNOWN`, chỉ là *ứng viên* nếu remote address/cổng bằng không; `2` là LISTEN và mọi state không được nhận diện sẽ HOLD.
3. **Bảo vệ sở hữu**: mọi bản ghi cùng cổng phải thuộc PID con đã tạo; địa chỉ chỉ `127.0.0.1` hoặc `::1`; không wildcard `0.0.0.0/::`, không LAN, không có PID lạ, không trùng hai bản ghi ứng viên cùng họ địa chỉ. Xác minh `ollama.exe`, đường dẫn executable đã ghim, `CreationDate` từ Win32_Process; khóa nguồn/model/executable bằng SHA. Nếu thiếu hoặc thay đổi danh tính thì HOLD.
4. **Xác minh kép bắt buộc**: trước HTTP chụp native snapshot và danh tính, sau đó chỉ gọi **GET** trực tiếp `http://127.0.0.1:12646/api/version` không proxy; bắt buộc 200/phiên bản 0.40.14, rồi chụp lại native socket và danh tính. PID, CreationDate và tập socket ứng viên phải khớp. Với trạng thái 0, quyết định tên rõ ràng `READY_DUAL_ATTESTED_STATE_ZERO_UNKNOWN` — **không** `LISTEN_PASS`.
5. **Bảo vệ nhập GGUF trong thiết kế đường chạy nội bộ**: sau khi sẵn sàng vẫn phải xác minh kép trước và sau `create`; kiểm tra manifest trong kho riêng và tag model trước `generate`; tùy chọn ngữ cảnh 256, tối đa 32 token, prompt tổng hợp. Sau chạy trả đủ bằng chứng, dừng đúng cây PID con, chặn chạy lại nếu thư mục claim đã tồn tại.
6. **Khóa thực thi**: CLI chỉ nhận `--mode contract`; `--mode execute` bị từ chối; hàm `execute()` có chốt `SOURCE_ONLY_EXECUTION_LOCK=True`. 114 bài QA hoàn toàn dựa trên fixture và mô phỏng, kể cả mô phỏng `serve → create → manifest → generate`. **Không chạy Ollama thật**.

## 3. Kiểm định độc lập

QA offline `test_independent_dual_attest.py`: 114/114 PASS, không có FAIL. Kiểm tra parser IPv4/IPv6, trạng thái 0 và 2, wildcard/remote nonzero, PID và creation time sai, HTTP 503/version sai, race sau HTTP, journal ghi độc quyền/flush, lock thực thi và mô phỏng đường chạy hoàn chỉnh (cả positive và negative).

**Chưa kiểm định:** PowerShell 5.1 native Windows với nguồn RC2, IP Helper thực tế trên cổng 12646, import GGUF, Ollama inference và so sánh logits. Các giả lập không chứng minh tình trạng mạng khi Ollama đang chạy.

## 4. Kết luận và quyết định

- `SOURCE_ONLY_DESIGN=COMPLETE`
- `OFFLINE_INDEPENDENT_QA=PASS_114_OF_114`
- `WINDOWS_NATIVE_STATIC_QA=NOT_EXECUTED`
- `V4_DUAL_RC2_RUNTIME=LOCKED_NOT_AUTHORIZED`
- `V1_V2_RC1=CONSUMED_PRESERVED`
- `TTM_OLLAMA_COMPATIBILITY=NOT_ESTABLISHED`
- `T5_STRICT_PARITY=FAIL_7_OF_8_PRESERVED`

Bước tiếp theo (một lần, không micro-gates): `TTM_T5_DUAL_ATTEST_WINDOWS_STATIC_QA_READBACK_AND_ONE_GUARDED_RELEASE_DECISION`. Ghim SHA nguồn/ZIP trên Windows, chạy QA tĩnh bằng PowerShell 5.1 và Python 3.12, sau đó phán quyết tích hợp về **một** bản runtime riêng có SHA mới. Bước hiện tại **không cấp phép** RC2 thực thi và không đụng `main` hay `lineage.md`.

## Tham chiếu giao diện hệ điều hành

- https://learn.microsoft.com/en-us/windows/win32/api/tcpmib/ns-tcpmib-mib_tcprow_owner_pid
- https://learn.microsoft.com/en-us/windows/win32/api/tcpmib/ns-tcpmib-mib_tcp6row_owner_pid
- https://learn.microsoft.com/en-us/windows/win32/api/iphlpapi/nf-iphlpapi-getextendedtcptable
