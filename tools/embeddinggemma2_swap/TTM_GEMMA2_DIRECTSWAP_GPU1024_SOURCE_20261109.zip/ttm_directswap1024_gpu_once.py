#!/usr/bin/env python3
"""One 1024x4096 per arm CUDA T4 continuation experiment with exact-resume.

New steps on the SAME historical trained step1024 P02 checkpoint in all four arms.
Claims before any optimization; VALIDATION scored only after all four arms end.
Never opens TEST, RAG, TinyStories raw text, or original T4 optimizer for training.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time

import numpy as np
import torch
from torch.nn import functional as F

RUN_ID = "ttm_small4m_gemma2_directswap_1024x4096_t4_gpu_20261109_v1"
PREREG_COMMIT = "6715c0a46aa30c3e4fee8647d4540d523d26c619"
SEED = 20261109
TRAIN_SAMPLER_SEED = SEED + 71
STEPS = 1024
LABELS_PER_STEP = 4096
MICROBATCH_WINDOWS = 8
CHECKPOINT_STEPS = (256, 512, 768, 1024)
ARMS = ("A", "B", "C", "D")
BOOT = 1000
GPU_SECONDS_LIMIT = 5400
PINS = {
    "checkpoint.pt": "cb985751795c8328ad65acf7ca4c1033ce35182c1bfbdb8c38550de629cb271b",
    "candidate_initialization.pt": "c9fc798d8880c7e76636258052e9885dbb086d7b462a5b6bee5cff8b582973c3",
    "T4_PRIVATE_TRAIN_VAL_WINDOWS.npz": "184f68b4c0c800ef3e98362c2e20e1cd35baa269e926489a475664526ecd9913",
    "T4_PRIVATE_PACK_MANIFEST.json": "ef2e6e67d49b1d5a921b1051df329f15574f1c10cece0ce49468acb53322d650",
    "p02_exact.py": "e0fcac285918b66b13c8f694e6d625a0691c9b59221b43043e63f46b25ddcc07",
    "ttm_embeddinggemma2_swap.py": "d11da61e9d7bb040f3263e680f026817a513553c186ab243e184ffaf6e68cd39",
}


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")


def write_json_new(path: Path, obj) -> None:
    with path.open("x", encoding="utf-8") as fp:
        json.dump(obj, fp, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)
        fp.write("\n")
        fp.flush()
        os.fsync(fp.fileno())


def hash_and_require(path: Path, name: str, expected: str) -> None:
    if not path.is_file() or path.is_symlink() or sha_file(path) != expected:
        raise RuntimeError("STOP_SHA256_PIN_VIOLATION:" + name)


def load_pack(pack_path: Path, manifest_path: Path):
    m = json.loads(manifest_path.read_text("utf-8"))
    if m.get("schema") != "ttm.t4.private.train_val.windowpack.v1" or m.get("contains_test") is not False:
        raise RuntimeError("NO_TEST_MANIFEST_CONTRACT_BROKEN")
    if m.get("npz_sha256") != PINS["T4_PRIVATE_TRAIN_VAL_WINDOWS.npz"]:
        raise RuntimeError("DATA_PACK_MANIFEST_SHA_REFUSED")
    expected = {f"{p}_{k}" for p in ("train", "val") for k in ("x", "y", "count", "story_index")}
    with np.load(pack_path, allow_pickle=False) as bundle:
        if set(bundle.files) != expected:
            raise RuntimeError("DATA_PACK_KEY_SET_MUST_BE_TRAIN_AND_VAL_ONLY")
        data = {k: bundle[k].astype(np.int64) for k in expected}
    for split, windows, stories, tokens in [("train", 2691, 2048, 498287), ("val", 328, 256, 61122)]:
        x, y, counts, si = (data[f"{split}_{k}"] for k in ("x", "y", "count", "story_index"))
        if x.shape != (windows, 256) or y.shape != x.shape or counts.shape != (windows,) or si.shape != (windows,):
            raise RuntimeError("PRIVATE_PACK_SHAPE_INVALID:" + split)
        mask = np.arange(256)[None, :] < counts[:, None]
        if (np.any(counts < 1) or np.any(counts > 256)
                or np.any(x < 0) or np.any(x >= 2048)
                or not np.all(y[~mask] == -100)
                or np.any(y[mask] < 0) or np.any(y[mask] >= 2048)
                or int(counts.sum()) != tokens
                or not np.array_equal(np.unique(si), np.arange(stories))):
            raise RuntimeError("PRIVATE_PACK_MASK_OR_PROVENANCE_INVALID:" + split)
    return data


def build_train_schedule(counts: np.ndarray):
    rng = np.random.default_rng(TRAIN_SAMPLER_SEED)
    schedule = []
    for step in range(STEPS):
        remaining = LABELS_PER_STEP
        ids, limits = [], []
        while remaining:
            i = int(rng.integers(0, len(counts)))
            k = min(int(counts[i]), remaining)
            if k < 1:
                raise RuntimeError("TRAIN_SAMPLER_ZERO_COUNT")
            ids.append(i)
            limits.append(k)
            remaining -= k
        if sum(limits) != LABELS_PER_STEP:
            raise RuntimeError("EXACT_LABELS_PER_STEP_BROKEN")
        schedule.append((ids, limits))
    return schedule, hashlib.sha256(canonical(schedule)).hexdigest()


def build_model(arm: str, p02, sw, ckpt, donor) -> torch.nn.Module:
    # Rebuild from exact trained original checkpoint, NEVER 64-step trained weights.
    torch.manual_seed(SEED)
    base = p02.GPT(sw.p02_config(p02)).float()
    base.load_state_dict(ckpt["model"], strict=True)
    if arm == "A":
        return base
    if arm == "B":
        return sw.control_untied(base)
    candidate_state = donor["model_state_dict"]
    src, valid = candidate_state["tok.source.weight"], candidate_state["tok.valid"]
    if src.shape != (2048, 512) or int(valid.sum()) != 1917 or bool(valid[256]):
        raise RuntimeError("DONOR_TENSOR_INVALID")
    if arm == "C":
        model = sw.control_untied(base)
        model.tok = sw.MappedGemmaInput(src, valid, candidate_state["tok.fallback"], candidate_state["tok.proj.weight"])
        model.load_state_dict(candidate_state, strict=True)
        return model
    if arm == "D":
        ids = torch.where(valid)[0]
        perm = np.random.default_rng(SEED).permutation(len(ids))
        shuffled = src.clone()
        shuffled[ids] = src[ids][torch.tensor(perm.copy(), dtype=torch.long)]
        return sw.build_swap(base, shuffled, valid, ridge=0.01)
    raise RuntimeError("UNKNOWN_ARM")


def preclaim(args):
    paths = {
        "checkpoint.pt": args.base,
        "candidate_initialization.pt": args.candidate,
        "T4_PRIVATE_TRAIN_VAL_WINDOWS.npz": args.pack,
        "T4_PRIVATE_PACK_MANIFEST.json": args.manifest,
        "p02_exact.py": args.source_dir / "p02_exact.py",
        "ttm_embeddinggemma2_swap.py": args.source_dir / "ttm_embeddinggemma2_swap.py",
    }
    for name, expected in PINS.items():
        hash_and_require(paths[name], name, expected)
    hash_and_require(Path(__file__), "RUNNER", args.runner_sha256)
    if args.output.is_symlink() or args.source_dir.is_symlink():
        raise RuntimeError("LINKED_OUTPUT_OR_SOURCE_REFUSED")
    if args.output.exists() != bool(args.resume):
        raise RuntimeError("ONE_SHOT_RUN_DIR_RESUME_CONTRACT_BROKEN")
    if (args.output / "RESULT.json").exists():
        raise RuntimeError("EXPERIMENT_ALREADY_CONSUMED_AND_COMPLETED")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA_GPU_REQUIRED_NO_CLAIM_CREATED")
    if "T4" not in torch.cuda.get_device_name(0):
        raise RuntimeError("EXPECTED_FREE_TESLA_T4_NO_CLAIM_CREATED")
    data = load_pack(args.pack, args.manifest)
    ckpt = torch.load(args.base, map_location="cpu", weights_only=True)
    donor = torch.load(args.candidate, map_location="cpu", weights_only=True)
    if (ckpt.get("step") != 1024 or ckpt.get("p02_git_blob") != "9762343e06cf800b50574c2871ae1ed58537fb18"
            or ckpt.get("train_pack_sha256") != PINS["T4_PRIVATE_TRAIN_VAL_WINDOWS.npz"]
            or ckpt.get("config") != {"vocab_size": 2048, "max_seq_len": 256, "n_embd": 256, "n_layer": 4, "n_head": 4, "norm_type": "layernorm"}):
        raise RuntimeError("ORIGINAL_STEP1024_PROVENANCE_INVALID")
    if (donor.get("schema") != "ttm.embeddinggemma2.token_swap.initialization.v1"
            or donor.get("source_checkpoint_sha256") != PINS["checkpoint.pt"]
            or donor.get("science_executed") is not False):
        raise RuntimeError("REAL_CANDIDATE_PROVENANCE_INVALID")
    sys.path.insert(0, str(args.source_dir))
    import ttm_embeddinggemma2_swap as sw
    p02 = sw.load_p02(args.source_dir / "p02_exact.py")
    torch.manual_seed(SEED)
    a = build_model("A", p02, sw, ckpt, donor)
    b = build_model("B", p02, sw, ckpt, donor)
    with torch.inference_mode():
        fixture = torch.tensor([[1, 42, 110, 500, 256, 300]], dtype=torch.long)
        if not torch.equal(a(fixture)[0], b(fixture)[0]):
            raise RuntimeError("NEGATIVE_CONTROL_A_B_INITIAL_LOGITS_MISMATCH")
    del a, b
    schedule, schedule_sha = build_train_schedule(data["train_count"])
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    return data, ckpt, donor, sw, p02, schedule, schedule_sha


def new_optimizer(model):
    return torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],
                             lr=1e-4, betas=(0.9, 0.95), eps=1e-8, weight_decay=0.1)


def save_checkpoint(args, arm, step, model, optimizer, losses, schedule_sha, gpu_seconds, source_sha):
    parent = args.output / "checkpoints" / arm
    parent.mkdir(parents=True, exist_ok=True)
    # An incomplete attempt is preserved, not overwritten. The same run can
    # resume from an earlier valid READY and write a different attempt suffix.
    idx = 0
    while (parent / f"step_{step:04d}_attempt_{idx:02d}").exists():
        idx += 1
        if idx > 9:
            raise RuntimeError("EXCESSIVE_PARTIAL_CHECKPOINT_ATTEMPTS")
    dest = parent / f"step_{step:04d}_attempt_{idx:02d}"
    dest.mkdir(exist_ok=False)
    tmp = args.scratch / f"{RUN_ID}_{arm}_step{step:04d}_attempt{idx:02d}.pt"
    if tmp.exists():
        raise RuntimeError("SCRATCH_TEMP_CHECKPOINT_EXISTS_NO_OVERWRITE")
    payload = {
        "schema": "ttm.gemma2.directswap1024.gpu.resumable.checkpoint.v1",
        "run_id": RUN_ID, "arm": arm, "step": step,
        "source_sha256": source_sha, "input_sha256": PINS,
        "schedule_sha256": schedule_sha,
        "model": model.state_dict(), "optimizer": optimizer.state_dict(),
        "train_losses": losses,
        "gpu_seconds_cumulative": gpu_seconds,
        "torch_rng_cpu": torch.get_rng_state(),
        "torch_rng_cuda": torch.cuda.get_rng_state_all(),
    }
    torch.save(payload, tmp)
    local_sha = sha_file(tmp)
    local_bytes = tmp.stat().st_size
    dst = dest / "checkpoint.pt"
    with tmp.open("rb") as fsrc, dst.open("xb") as fdst:
        shutil.copyfileobj(fsrc, fdst, length=1 << 20)
        fdst.flush()
        os.fsync(fdst.fileno())
    if sha_file(dst) != local_sha or dst.stat().st_size != local_bytes:
        raise RuntimeError("DRIVE_CHECKPOINT_READBACK_SHA_INVALID")
    write_json_new(dest / "READY.json", {
        "schema": "ttm.gemma2.directswap1024.checkpoint.ready.last.v1",
        "run_id": RUN_ID, "arm": arm, "step": step,
        "checkpoint_sha256": local_sha, "checkpoint_bytes": local_bytes,
        "schedule_sha256": schedule_sha, "source_sha256": source_sha,
    })
    tmp.unlink()
    print(f"TTM_GPU1024_READY arm={arm} step={step} sha256={local_sha}", flush=True)


def latest_ready(args, arm, schedule_sha, source_sha):
    parent = args.output / "checkpoints" / arm
    if not parent.is_dir():
        return None
    available = []
    for d in parent.glob("step_*_attempt_*"):
        if not d.is_dir():
            raise RuntimeError("CHECKPOINT_TREE_SHAPE_INVALID")
        ready_path = d / "READY.json"
        if not ready_path.exists():
            continue  # incomplete attempt preserved in-place, not selected
        r = json.loads(ready_path.read_text("utf-8"))
        step = r.get("step")
        if (r.get("schema") != "ttm.gemma2.directswap1024.checkpoint.ready.last.v1"
                or r.get("run_id") != RUN_ID or r.get("arm") != arm
                or step not in CHECKPOINT_STEPS
                or r.get("schedule_sha256") != schedule_sha
                or r.get("source_sha256") != source_sha
                or d.name != f"step_{step:04d}_attempt_{int(d.name.rsplit('_', 1)[-1]):02d}"):
            raise RuntimeError("READY_CHECKPOINT_METADATA_INVALID")
        cp = d / "checkpoint.pt"
        if (not cp.is_file() or cp.stat().st_size != r.get("checkpoint_bytes")
                or sha_file(cp) != r.get("checkpoint_sha256")):
            raise RuntimeError("READY_CHECKPOINT_BYTES_CORRUPT_DO_NOT_RESUME")
        available.append((step, d))
    if not available:
        return None
    steps = [x[0] for x in available]
    if len(steps) != len(set(steps)):
        # A complete milestone must never have two accepted alternate states.
        raise RuntimeError("DUPLICATE_READY_FOR_SAME_STEP")
    return max(available, key=lambda x: x[0])


def restore_checkpoint(path, model, opt, arm, schedule_sha, source_sha):
    p = torch.load(path / "checkpoint.pt", map_location="cpu", weights_only=True)
    if (p.get("schema") != "ttm.gemma2.directswap1024.gpu.resumable.checkpoint.v1"
            or p.get("run_id") != RUN_ID or p.get("arm") != arm
            or p.get("schedule_sha256") != schedule_sha
            or p.get("source_sha256") != source_sha
            or p.get("input_sha256") != PINS):
        raise RuntimeError("RESTORED_STATE_SOURCE_MISMATCH")
    model.load_state_dict(p["model"], strict=True)
    opt.load_state_dict(p["optimizer"])
    torch.set_rng_state(p["torch_rng_cpu"])
    torch.cuda.set_rng_state_all(p["torch_rng_cuda"])
    if len(p["train_losses"]) != p["step"]:
        raise RuntimeError("RESTORED_LOG_LENGTH_INVALID")
    return int(p["step"]), list(p["train_losses"]), float(p["gpu_seconds_cumulative"])


def train_one_step(model, opt, step_batch, data, device):
    idxs, limits = step_batch
    if len(idxs) != len(limits) or sum(limits) != LABELS_PER_STEP:
        raise RuntimeError("STEP_TARGET_BUDGET_INVALID")
    model.train()
    opt.zero_grad(set_to_none=True)
    total_loss = 0.0
    for begin in range(0, len(idxs), MICROBATCH_WINDOWS):
        ii = idxs[begin: begin + MICROBATCH_WINDOWS]
        cc = limits[begin: begin + MICROBATCH_WINDOWS]
        x = np.stack(data["train_x"][ii], axis=0)
        y = np.stack(data["train_y"][ii], axis=0)
        for row, count in enumerate(cc):
            y[row, count:] = -100
        if sum(int(v) for v in (y != -100).sum(axis=1)) != sum(cc):
            raise RuntimeError("MISMATCHED_MICROBATCH_LABELS")
        xx = torch.from_numpy(x).to(device=device, dtype=torch.long, non_blocking=True)
        yy = torch.from_numpy(y).to(device=device, dtype=torch.long, non_blocking=True)
        logits, _ = model(xx)
        loss = F.cross_entropy(logits.float().reshape(-1, 2048), yy.reshape(-1),
                               ignore_index=-100, reduction="sum") / LABELS_PER_STEP
        if not bool(torch.isfinite(loss)):
            raise RuntimeError("NONFINITE_TRAIN_LOSS_NO_SILENT_RECOVERY")
        loss.backward()
        total_loss += float(loss.detach().cpu())
    grads = [p.grad for p in model.parameters() if p.requires_grad and p.grad is not None]
    if not grads or not all(bool(torch.isfinite(g).all()) for g in grads):
        raise RuntimeError("NONFINITE_OR_MISSING_GRADIENT")
    torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], 1.0)
    opt.step()
    return total_loss


@torch.inference_mode()
def val_story_sums(model, data, device):
    model.eval()
    sums = np.zeros(256, dtype=np.float64)
    for i in range(0, len(data["val_x"]), MICROBATCH_WINDOWS):
        j = min(i + MICROBATCH_WINDOWS, len(data["val_x"]))
        x = torch.from_numpy(data["val_x"][i:j].copy()).to(device=device, dtype=torch.long)
        y = torch.from_numpy(data["val_y"][i:j].copy()).to(device=device, dtype=torch.long)
        logits, _ = model(x)
        if not bool(torch.isfinite(logits).all()):
            raise RuntimeError("NONFINITE_FINAL_VAL_LOGITS")
        loss = F.cross_entropy(logits.float().reshape(-1, 2048), y.reshape(-1),
                               ignore_index=-100, reduction="none")
        part = loss.reshape(j - i, 256).sum(dim=1).double().cpu().numpy()
        np.add.at(sums, data["val_story_index"][i:j], part)
    return sums


def paired_ci(lhs: np.ndarray, rhs: np.ndarray, counts: np.ndarray):
    rng = np.random.default_rng(SEED)
    sel = rng.integers(0, 256, size=(BOOT, 256))
    score = (lhs - rhs)[sel].sum(axis=1) / counts[sel].sum(axis=1)
    return [float(v) for v in np.quantile(score, [0.025, 0.975])]


def execute(args):
    if args.scratch.is_symlink():
        raise RuntimeError("SCRATCH_SYMLINK_DISALLOWED")
    torch.set_num_threads(2)
    torch.manual_seed(SEED)
    torch.cuda.manual_seed_all(SEED)
    data, ckpt, donor, sw, p02, schedule, schedule_sha = preclaim(args)
    source_sha = sha_file(Path(__file__))
    current_env = {"torch": torch.__version__, "cuda": torch.version.cuda,
                   "gpu_name": torch.cuda.get_device_name(0),
                   "precision": "CUDA_FP32_NO_TF32", "microbatch_windows": MICROBATCH_WINDOWS}
    claim = {
        "schema": "ttm.gemma2.directswap1024.gpu.claim.v1",
        "run_id": RUN_ID, "source_sha256": source_sha,
        "prereg_commit": PREREG_COMMIT, "pins": PINS,
        "train_schedule_sha256": schedule_sha,
        "arms": list(ARMS), "steps_per_arm": STEPS,
        "labels_per_step": LABELS_PER_STEP,
        "target_exposures_per_arm": STEPS * LABELS_PER_STEP,
        "optimizer": {"name": "AdamW", "lr": 0.0001, "betas": [0.9, 0.95],
                      "eps": 1e-8, "weight_decay": 0.1, "grad_clip": 1.0},
        "train_seed": TRAIN_SAMPLER_SEED, "donor_permutation_seed": SEED,
        "bootstrap_seed": SEED, "bootstrap_rounds": BOOT,
        "environment": current_env, "max_gpu_seconds": GPU_SECONDS_LIMIT,
        "no_test": True, "resumable_same_run_id_only": True,
        "training_source": "EXISTING_TRAIN_ONLY_WINDOWS",
        "description": "1024 additional updates starting from original T4 trained step1024 weights, not training from scratch"
    }
    args.scratch.mkdir(parents=True, exist_ok=True)
    if args.resume:
        stored = json.loads((args.output / "CLAIM.json").read_text("utf-8"))
        if stored != claim:
            raise RuntimeError("RESUME_CLAIM_MISMATCH_NO_RESTART")
    else:
        args.output.mkdir(parents=True, exist_ok=False)
        write_json_new(args.output / "CLAIM.json", claim)
        write_json_new(args.output / "TRAIN_SCHEDULE_PRIVATE.json", {
            "run_id": RUN_ID, "sha256": schedule_sha, "schedule": schedule})
        print("TTM_GPU1024_CLAIM=CONSUMED RUN_ID=" + RUN_ID, flush=True)
    device = torch.device("cuda:0")
    cumulative = 0.0
    # On restart, accounting comes from the most advanced completed checkpoint.
    for arm in ARMS:
        model = build_model(arm, p02, sw, ckpt, donor).to(device=device, dtype=torch.float32)
        opt = new_optimizer(model)
        previous = latest_ready(args, arm, schedule_sha, source_sha)
        if previous:
            step0, losses, recorded = restore_checkpoint(previous[1], model, opt, arm, schedule_sha, source_sha)
            cumulative = max(cumulative, recorded)
            print(f"TTM_GPU1024_RESUME arm={arm} step={step0}", flush=True)
        else:
            step0, losses = 0, []
        if cumulative >= GPU_SECONDS_LIMIT:
            raise RuntimeError("GPU_BUDGET_CAP_EXCEEDED_NO_FURTHER_TRAIN")
        for step in range(step0 + 1, STEPS + 1):
            torch.cuda.synchronize(); start = time.perf_counter()
            avg_loss = train_one_step(model, opt, schedule[step - 1], data, device)
            torch.cuda.synchronize(); cumulative += time.perf_counter() - start
            losses.append(avg_loss)
            if step in (1, 64, 128, 256, 512, 768, 1024):
                print(f"TTM_GPU1024_ARM={arm} STEP={step} TRAIN_LOSS={avg_loss:.6f}", flush=True)
            if step in CHECKPOINT_STEPS:
                save_checkpoint(args, arm, step, model, opt, losses,
                                schedule_sha, cumulative, source_sha)
            if cumulative >= GPU_SECONDS_LIMIT:
                # No automatic extra permit or hidden new run. Preserve READY.
                print(f"TTM_GPU1024_STATUS=INCOMPLETE_BUDGET_CAP arm={arm} step={step}", flush=True)
                raise SystemExit(3)
        del model, opt
        torch.cuda.empty_cache()
    # Evaluate only after ALL arms have a complete step1024 READY.
    n_by_story = np.bincount(data["val_story_index"],
                             weights=data["val_count"], minlength=256).astype(np.int64)
    if not np.all(n_by_story > 0) or int(n_by_story.sum()) != 61122:
        raise RuntimeError("VAL_STORY_DENOMINATOR_INVALID")
    sums, final_hashes = {}, {}
    for arm in ARMS:
        model = build_model(arm, p02, sw, ckpt, donor).to(device=device, dtype=torch.float32)
        latest = latest_ready(args, arm, schedule_sha, source_sha)
        if latest is None or latest[0] != STEPS:
            raise RuntimeError("ARM_NOT_COMPLETE_FINAL_VAL_FORBIDDEN:" + arm)
        payload = torch.load(latest[1] / "checkpoint.pt", map_location="cpu", weights_only=True)
        model.load_state_dict(payload["model"], strict=True)
        sums[arm] = val_story_sums(model, data, device)
        final_hashes[arm] = sha_file(latest[1] / "checkpoint.pt")
        print(f"TTM_GPU1024_FINAL_NLL arm={arm} value={sums[arm].sum()/61122:.9f}", flush=True)
        del model
        torch.cuda.empty_cache()
    nll = {k: float(v.sum() / 61122) for k, v in sums.items()}
    cis = {name: paired_ci(sums[left], sums[right], n_by_story)
           for name, left, right in (("A_minus_C", "A", "C"),
                                      ("B_minus_C", "B", "C"),
                                      ("D_minus_C", "D", "C"))}
    passed = all(x[0] > 0 for x in cis.values())
    per_story = {
        "schema": "ttm.gemma2.directswap1024.private.perstory.v1",
        "run_id": RUN_ID, "n_targets_by_story": n_by_story.tolist(),
        "loss_sums_by_arm": {k: v.tolist() for k,v in sums.items()},
    }
    write_json_new(args.output / "PER_STORY_PRIVATE.json", per_story)
    result = {
        "schema": "ttm.gemma2.directswap1024.gpu.result.v1",
        "run_id": RUN_ID, "status": "COMPLETED_UNADJUDICATED",
        "exploratory_label": ("DIRECT_SWAP_1024_POSITIVE_EXPLORATORY" if passed
                               else "DIRECT_SWAP_1024_BENEFIT_NOT_ESTABLISHED"),
        "nll_val": nll, "confidence_interval_95pct": cis,
        "nll_differences": {key: nll[a] - nll[b]
           for key,a,b in (("A_minus_C","A","C"),("B_minus_C","B","C"),("D_minus_C","D","C"))},
        "prereg_commit": PREREG_COMMIT,
        "source_sha256": source_sha, "source_inputs_sha256": PINS,
        "final_checkpoint_sha256": final_hashes,
        "per_story_sha256": sha_file(args.output / "PER_STORY_PRIVATE.json"),
        "train_schedule_sha256": schedule_sha,
        "steps_each_arm": STEPS, "labels_each_step": LABELS_PER_STEP,
        "train_targets_each_arm": STEPS * LABELS_PER_STEP,
        "total_train_targets": STEPS * LABELS_PER_STEP * len(ARMS),
        "val_stories": 256, "val_windows": 328, "val_targets": 61122,
        "gpu_seconds_cumulative": cumulative,
        "test_read": False, "preexisting_checkpoints_overwritten": False,
        "validation_scored_once_after_training": True,
        "limitations": ["From original T4 step1024, NOT from scratch",
           "Reused VALIDATION, one seed: exploratory only",
           "Equal steps and labels, NOT equal FLOPs",
           "Raw Gemma donor rows fixed; adapter and decoder trainable"],
    }
    write_json_new(args.output / "RESULT.json", result)
    print("TTM_GPU1024_STATUS=COMPLETED_UNADJUDICATED", flush=True)
    print("TTM_GPU1024_EXPLORATORY_LABEL=" + result["exploratory_label"], flush=True)
    print("TTM_GPU1024_RESULT=" + str(args.output / "RESULT.json"), flush=True)


def parse_args(argv=None):
    p = argparse.ArgumentParser()
    for key in ("base", "candidate", "pack", "manifest", "source_dir", "output", "scratch"):
        p.add_argument("--" + key.replace("_", "-"), type=Path, required=True)
    p.add_argument("--runner-sha256", required=True)
    p.add_argument("--resume", action="store_true")
    return p.parse_args(argv)


if __name__ == "__main__":
    execute(parse_args())
