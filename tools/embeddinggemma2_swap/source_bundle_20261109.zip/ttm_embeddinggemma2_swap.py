#!/usr/bin/env python3
"""Experimental TTM-Small-4M input-token embedding replacement.

The default CPU smoke uses SYNTHETIC donor vectors and SYNTHETIC token IDs.
It proves tensor integration, causal masking, gradients, and preservation of an
untied-output control; it does NOT test genuine EmbeddingGemma-2 transfer.

The optional real-build reads only an already-local, exact-hash-pinned donor
snapshot and existing TTM tokenizer and step-1024 checkpoint. It never downloads,
reads TEST, trains on TinyStories, or overwrites original artifacts.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import time
from typing import Callable

import torch
from torch import nn
from torch.nn import functional as F

P02_SHA256 = 'e0fcac285918b66b13c8f694e6d625a0691c9b59221b43043e63f46b25ddcc07'
DONOR_REV = 'f9972ac22e696a105c482202646979e33e4b5a1e'
DONOR_SAFETENSORS_SHA256 = '197a32965d4b1105faf060417baa899e193fb73cd401f42ec9295234d5553d79'
DONOR_TOKENIZER_SHA256 = '4d777ef5bdc1aa36227abdfb77c3e49e7b9c892d16e1b6bda41c393504828be4'
DONOR_TOKENIZER_CONFIG_SHA256 = '17bd5d6e9364ca49a534e1502076593317c298d4a663623091ed45388f004874'
DONOR_CONFIG_SHA256 = 'b8f1e9931b57fbc054acdb445c41765d55b0074c58d145fa82839941ad1b5bb3'
TTM_TRAIN_BPE_MANIFEST_SHA256 = 'cba18e60cee3d08a353ee6d4a451017289e45af7b4b1179c87171b9b78d7dfdc'
TTM_T4_STEP1024_CHECKPOINT_SHA256 = 'cb985751795c8328ad65acf7ca4c1033ce35182c1bfbdb8c38550de629cb271b'
TTM_VOCAB = 2048
TTM_HIDDEN = 256
DONOR_HIDDEN = 512
TTM_EOS = 256
EXPECTED_ORIGINAL_PARAMS = 3749376


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as fd:
        for chunk in iter(lambda: fd.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def require_sha(path: Path, expected: str) -> None:
    if not path.is_file() or sha256(path) != expected:
        raise RuntimeError('PINNED_SHA256_MISMATCH_OR_MISSING: ' + path.name)


def load_p02(p02_path: Path):
    require_sha(p02_path, P02_SHA256)
    spec = importlib.util.spec_from_file_location('ttm_p02_exact_proof', p02_path)
    if spec is None or spec.loader is None:
        raise RuntimeError('P02_IMPORT_FAILED')
    import sys
    import types
    m = importlib.util.module_from_spec(spec)
    sys.modules[m.__name__] = m
    spec.loader.exec_module(m)
    return m


def p02_config(p02):
    return p02.P02Config(vocab_size=2048, max_seq_len=256, n_embd=256,
                         n_layer=4, n_head=4, norm_type='layernorm')


class MappedGemmaInput(nn.Module):
    """256-wide embedding, 512-wide frozen donor token vectors + trainable projection.

    For incomplete UTF-8 BPE fragments, special EOS, or tokenizer errors,
    retain the corresponding original TTM input row (frozen, not shared with head).
    The donor transformer/context pooling is NOT invoked in the TTM forward path.
    """
    def __init__(self, mapped_rows: torch.Tensor, valid: torch.Tensor,
                 original_ttm_rows: torch.Tensor, projection: torch.Tensor):
        super().__init__()
        if (mapped_rows.shape != (TTM_VOCAB, DONOR_HIDDEN)
                or original_ttm_rows.shape != (TTM_VOCAB, TTM_HIDDEN)
                or valid.shape != (TTM_VOCAB,)
                or valid.dtype is not torch.bool
                or projection.shape != (TTM_HIDDEN, DONOR_HIDDEN)):
            raise ValueError('INVALID_EMBEDDING_TRANSFER_SHAPES')
        if valid[TTM_EOS].item():
            raise ValueError('EOS_MUST_KEEP_ORIGINAL_TTM_ROW')
        if not torch.isfinite(mapped_rows).all() or not torch.isfinite(projection).all():
            raise ValueError('NONFINITE_INPUT_EMBEDDING')
        if not torch.isfinite(original_ttm_rows).all():
            raise ValueError('NONFINITE_ORIGINAL_INPUT')
        self.source = nn.Embedding.from_pretrained(mapped_rows.detach().float().clone(), freeze=True)
        self.proj = nn.Linear(DONOR_HIDDEN, TTM_HIDDEN, bias=False)
        with torch.no_grad():
            self.proj.weight.copy_(projection.float())
        self.register_buffer('valid', valid.detach().clone())
        self.register_buffer('fallback', original_ttm_rows.detach().float().clone())

    def forward(self, token_ids: torch.Tensor) -> torch.Tensor:
        candidate = self.proj(self.source(token_ids))
        return torch.where(self.valid[token_ids].unsqueeze(-1), candidate,
                           F.embedding(token_ids, self.fallback))


def control_untied(base: nn.Module) -> nn.Module:
    """A fair control: same weights as baseline but input/output no longer tied."""
    result = copy.deepcopy(base)
    with torch.no_grad():
        old_head = base.head.weight.detach().clone()
    new_head = nn.Linear(TTM_HIDDEN, TTM_VOCAB, bias=False)
    new_head.weight = nn.Parameter(old_head)
    result.head = new_head
    if result.tok.weight.data_ptr() == result.head.weight.data_ptr():
        raise AssertionError('UNTIE_FAILED')
    return result


def ridge_align(mapped_rows: torch.Tensor, valid: torch.Tensor,
                target_ttm_rows: torch.Tensor, ridge: float = 0.01) -> torch.Tensor:
    """No dataset or labels: regress donor TOKEN vectors to frozen TTM input rows.

    The objective is initial numerical continuity, not an evidence-backed claim
    of better language representations. Must not consult VAL or TEST.
    """
    mask = valid.detach().cpu()
    x = mapped_rows.detach().float().cpu()[mask]
    y = target_ttm_rows.detach().float().cpu()[mask]
    if x.ndim != 2 or x.shape[0] < 512:
        raise ValueError('INSUFFICIENT_MAPPABLE_VOCAB_FOR_512_TO_256_ALIGNMENT')
    xtx = x.T @ x
    a = xtx + ridge * torch.eye(DONOR_HIDDEN, dtype=torch.float32)
    p = torch.linalg.solve(a, x.T @ y)  # 512 x 256
    return p.T.contiguous()  # torch.nn.Linear weight: 256 x 512


def build_swap(base: nn.Module, mapped_rows: torch.Tensor, valid: torch.Tensor,
               ridge: float = .01) -> nn.Module:
    model = control_untied(base)
    p = ridge_align(mapped_rows, valid, base.tok.weight.detach(), ridge)
    model.tok = MappedGemmaInput(mapped_rows, valid, base.tok.weight.detach(), p)
    if model.head.weight.data_ptr() == base.head.weight.data_ptr():
        raise AssertionError('BASELINE_HEAD_SHARES_STORAGE')
    return model


def byte_to_unicode():
    bs = list(range(33,127)) + list(range(161,173)) + list(range(174,256))
    cs = bs.copy()
    n = 0
    for i in range(256):
        if i not in bs:
            bs.append(i)
            cs.append(256 + n)
            n += 1
    return dict(zip(bs, map(chr, cs)))


def map_bpe_tokens(tokens: list[str], donor_tokenizer, donor_embedding: torch.Tensor):
    """Map raw TTM byte-BPE pieces into Gemma IDs *without* adding BOS/EOS.

    Incomplete UTF-8 fragments are NOT decoded with replacement characters:
    they fall back to the original input embedding row. The mean of donor input
    lookup vectors is a heuristic; its linguistic merit is not presupposed.
    """
    if len(tokens) != TTM_VOCAB:
        raise ValueError('TTM_VOCAB_SIZE_CHANGED')
    if tokens[TTM_EOS] != '<|endoftext|>':
        raise ValueError('TTM_EOS_CHANGED')
    if donor_embedding.shape != (262144, DONOR_HIDDEN):
        raise ValueError('DONOR_TOKEN_TABLE_SIZE_CHANGED')
    inv = {v: k for k, v in byte_to_unicode().items()}
    rows = torch.zeros((TTM_VOCAB, DONOR_HIDDEN), dtype=torch.float32)
    mask = torch.zeros((TTM_VOCAB,), dtype=torch.bool)
    counters = {'valid_utf8': 0, 'incomplete_utf8': 0, 'empty_or_special': 0,
                'unmapped_or_invalid_donor_ids': 0, 'mapped': 0, 'multi_id_mapped': 0}
    all_special = set(getattr(donor_tokenizer, 'all_special_ids', []))
    for i, piece in enumerate(tokens):
        if i == TTM_EOS:
            counters['empty_or_special'] += 1
            continue
        try:
            bs = bytes(inv[c] for c in piece)
            txt = bs.decode('utf-8', errors='strict')
        except (UnicodeError, KeyError):
            counters['incomplete_utf8'] += 1
            continue
        counters['valid_utf8'] += 1
        if not txt:
            counters['empty_or_special'] += 1
            continue
        ids = donor_tokenizer.encode(txt, add_special_tokens=False)
        if (not isinstance(ids, list) or not ids or
            any(type(z) is not int or z < 0 or z >= donor_embedding.shape[0] or
                z in all_special for z in ids)):
            counters['unmapped_or_invalid_donor_ids'] += 1
            continue
        row = donor_embedding[ids].to(dtype=torch.float32).mean(dim=0)
        if not bool(torch.isfinite(row).all()):
            raise ValueError('NONFINITE_PINNED_DONOR_ROW')
        rows[i] = row
        mask[i] = True
        counters['mapped'] += 1
        if len(ids) > 1:
            counters['multi_id_mapped'] += 1
    if counters['mapped'] + counters['incomplete_utf8'] + counters['empty_or_special'] + counters['unmapped_or_invalid_donor_ids'] != 2048:
        raise AssertionError('MAPPING_COUNTS_INCOMPLETE')
    return rows, mask, counters


def cpu_smoke(p02_path: Path):
    torch.set_num_threads(min(2, torch.get_num_threads()))
    p02 = load_p02(p02_path)
    torch.manual_seed(20261109)
    cfg = p02_config(p02)
    base = p02.GPT(cfg).float().eval()
    assert sum(p.numel() for p in base.parameters()) == EXPECTED_ORIGINAL_PARAMS
    base_weights = {k: v.detach().clone() for k, v in base.state_dict().items()}
    ctrl = control_untied(base).eval()
    g = torch.Generator().manual_seed(20261110)
    # This is intentionally NOT a real Gemma table or real BPE alignment.
    synthetic_donor = .015 * torch.randn(TTM_VOCAB, DONOR_HIDDEN, generator=g)
    synthetic_mask = torch.ones(TTM_VOCAB, dtype=torch.bool)
    synthetic_mask[TTM_EOS] = False
    synthetic_mask[130:231] = False
    swap = build_swap(base, synthetic_donor, synthetic_mask).eval()
    seq = torch.tensor([[1, 10, 120, 256, 200, 300, 11, 32],
                        [7, 51, 260, 28, 1024, 2047, 17, 21]], dtype=torch.long)
    target = seq.roll(-1, 1)
    with torch.no_grad():
        baseline_logits, baseline_loss = base(seq, target)
        ctrl_logits, ctrl_loss = ctrl(seq, target)
        swap_logits, swap_loss = swap(seq, target)
    if not torch.equal(baseline_logits, ctrl_logits) or not torch.equal(baseline_loss, ctrl_loss):
        raise AssertionError('UNTIED_CONTROL_NOT_LOGIT_EXACT')
    if tuple(swap_logits.shape) != (2, 8, 2048) or not bool(torch.isfinite(swap_loss)):
        raise AssertionError('SWAPPED_FORWARD_FAILED')
    if swap.head.weight.data_ptr() == swap.tok.proj.weight.data_ptr():
        raise AssertionError('SWAPPED_HEAD_COUPLING')
    eos_ids = torch.full((2, 1), TTM_EOS, dtype=torch.long)
    torch.testing.assert_close(swap.tok(eos_ids),
                               F.embedding(eos_ids, swap.tok.fallback),
                               atol=0, rtol=0)
    # True causal isolation: perturb a future ID, earlier logits must match.
    altered = seq.clone(); altered[:, -1] = 126
    with torch.no_grad():
        a, _ = swap(seq)
        b, _ = swap(altered)
    torch.testing.assert_close(a[:, :-1], b[:, :-1], atol=0, rtol=0)
    swap.train()
    _, loss = swap(seq, target)
    loss.backward()
    if (swap.tok.proj.weight.grad is None or
        not bool(torch.isfinite(swap.tok.proj.weight.grad).all()) or
        swap.tok.source.weight.grad is not None or
        swap.head.weight.grad is None):
        raise AssertionError('SWAPPED_BACKWARD_FAILED')
    # Neither the baseline parameters nor their buffers may change.
    if any(not torch.equal(v, base.state_dict()[k]) for k,v in base_weights.items()):
        raise AssertionError('BASELINE_CHANGED')
    # Save/reload check for untied model shape and outputs.
    swap.eval()
    with tempfile.TemporaryDirectory() as d:
        dst = Path(d) / 'candidate_state.pt'
        torch.save(swap.state_dict(), dst)
        reloaded = build_swap(base, synthetic_donor, synthetic_mask).eval()
        reloaded.load_state_dict(torch.load(dst, map_location='cpu', weights_only=True), strict=True)
        with torch.no_grad():
            after, _ = reloaded(seq)
            before, _ = swap(seq)
        torch.testing.assert_close(after, before, atol=0, rtol=0)
    return {
        'verdict': 'PASS_CPU_SYNTHETIC_STRUCTURE_ONLY',
        'source_p02_sha256': P02_SHA256,
        'baseline_parameter_count': EXPECTED_ORIGINAL_PARAMS,
        'baseline_logits_unchanged_by_untie': True,
        'swap_logits_shape': [2,8,2048],
        'synthetic_swapped_loss': float(swap_loss),
        'synthetic_baseline_loss': float(baseline_loss),
        'synthetic_mappable_rows': int(synthetic_mask.sum()),
        'input_donor_shape': list(synthetic_donor.shape),
        'projection_shape': list(swap.tok.proj.weight.shape),
        'donor_lookup_frozen': True,
        'causal_future_isolation': True,
        'gradient_to_projection': True,
        'state_save_reload_exact': True,
        'original_model_unchanged': True,
        'real_donor_data_used': False,
        'real_checkpoint_used': False,
        'actual_tinystories_used': False,
        'gpu_used': False,
        'test_used': False,
        'scientific_conclusion': 'NONE',
    }


def real_build(p02_path: Path, manifest: Path, donor_dir: Path,
               checkpoint: Path, output: Path):
    """Only local pinned inputs. No new scientific run or corpus access."""
    from safetensors import safe_open
    from transformers import AutoTokenizer  # optional, not needed for CPU smoke
    if output.exists():
        raise FileExistsError('OUTPUT_DIRECTORY_ALREADY_EXISTS_NO_OVERWRITE')
    p02 = load_p02(p02_path)
    require_sha(manifest, TTM_TRAIN_BPE_MANIFEST_SHA256)
    require_sha(checkpoint, TTM_T4_STEP1024_CHECKPOINT_SHA256)
    for name, digest in [
        ('model.safetensors', DONOR_SAFETENSORS_SHA256),
        ('tokenizer.json', DONOR_TOKENIZER_SHA256),
        ('tokenizer_config.json', DONOR_TOKENIZER_CONFIG_SHA256),
        ('config.json', DONOR_CONFIG_SHA256),
    ]:
        require_sha(donor_dir / name, digest)
    meta = json.loads(manifest.read_text(encoding='utf-8'))
    if meta.get('vocab_size') != 2048 or meta.get('eos_id') != TTM_EOS:
        raise RuntimeError('TTM_BPE_MANIFEST_INVALID')
    # Re-evaluate the internal manifest digest, never accept an unverified token list.
    raw_meta = dict(meta)
    claimed_sha = raw_meta.pop('manifest_sha256', None)
    canon = json.dumps(raw_meta, ensure_ascii=False, sort_keys=True,
                       separators=(',', ':')).encode('utf-8')
    if hashlib.sha256(canon).hexdigest() != claimed_sha:
        raise RuntimeError('TTM_BPE_INTERNAL_SHA_MISMATCH')
    cfg_meta = json.loads((donor_dir / 'config.json').read_text('utf8'))
    if (cfg_meta['text_config']['hidden_size'] != DONOR_HIDDEN or
        cfg_meta['text_config']['vocab_size'] != 262144):
        raise RuntimeError('PINNED_DONOR_MODEL_CONFIG_CHANGED')
    tok = AutoTokenizer.from_pretrained(str(donor_dir), local_files_only=True)
    weights = donor_dir / 'model.safetensors'
    with safe_open(str(weights), framework='pt', device='cpu') as s:
        names = [key for key in s.keys() if key.endswith('embed_tokens.weight') and
                 list(s.get_slice(key).get_shape()) == [262144, DONOR_HIDDEN]]
        if len(names) != 1:
            raise RuntimeError('DONOR_INPUT_EMBEDDING_TENSOR_NOT_UNIQUE:' + str(names))
        donor = s.get_tensor(names[0]).float()
        rows,mask,counts = map_bpe_tokens(meta['tokens'], tok, donor)
        del donor
    ckpt = torch.load(checkpoint, map_location='cpu', weights_only=True)
    if ckpt.get('step') != 1024 or ckpt.get('p02_git_blob') != '9762343e06cf800b50574c2871ae1ed58537fb18':
        raise RuntimeError('TTM_STEP_OR_ARCH_MISMATCH')
    base = p02.GPT(p02_config(p02)).float().eval()
    base.load_state_dict(ckpt['model'], strict=True)
    if sum(p.numel() for p in base.parameters()) != EXPECTED_ORIGINAL_PARAMS:
        raise RuntimeError('TTM_CONFIG_CHANGED')
    if counts['mapped'] < 512:
        raise RuntimeError('INSUFFICIENT_SEMANTIC_TRANSFER_COVERAGE')
    swapped = build_swap(base, rows, mask).eval()
    # No TinyStories, VAL, TEST, or optimizer steps. Safe single synthetic input.
    x = torch.tensor([[1, 42, 110, 500, 256]],dtype=torch.long)
    with torch.no_grad():
        logits, _ = swapped(x)
    if logits.shape != (1,5,2048) or not bool(torch.isfinite(logits).all()):
        raise RuntimeError('REAL_DONOR_STRUCTURE_SMOKE_FAILED')
    output.mkdir(parents=True, exist_ok=False)
    candidate = output / 'candidate_initialization.pt'
    torch.save({'schema':'ttm.embeddinggemma2.token_swap.initialization.v1',
                'model_state_dict':swapped.state_dict(),
                'source_checkpoint_sha256':TTM_T4_STEP1024_CHECKPOINT_SHA256,
                'donor_source_sha256':DONOR_SAFETENSORS_SHA256,
                'mapping_counts':counts,
                'science_executed':False},candidate)
    report = {'status':'PASS_REAL_DONOR_INTEGRATION_ONLY_NO_TRAIN_NO_VALIDATION',
              'candidate_sha256':sha256(candidate),
              'ttm_manifest_sha256':sha256(manifest),
              'checkpoint_sha256':sha256(checkpoint),
              'donor_rev':DONOR_REV, 'donor_tensor_name':names[0],
              'mapping':counts, 'actual_model_forward_finite':True,
              'science_executed':False, 'validation_read':False, 'test_read':False}
    (output / 'PROOF_RESULT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n',encoding='utf8')
    return report


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--mode',choices=('cpu-smoke','real-build'),required=True)
    parser.add_argument('--p02',required=True,type=Path)
    parser.add_argument('--ttm-tokenizer',type=Path)
    parser.add_argument('--donor-dir',type=Path)
    parser.add_argument('--checkpoint',type=Path)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    if args.mode=='cpu-smoke':
        result=cpu_smoke(args.p02)
        print('TTM_EMBED_SWAP_CPU_PROOF='+result['verdict'])
        print(json.dumps(result,sort_keys=True))
    else:
        if not all((args.ttm_tokenizer,args.donor_dir,args.checkpoint,args.output)):
            parser.error('real-build needs --ttm-tokenizer --donor-dir --checkpoint --output')
        report=real_build(args.p02,args.ttm_tokenizer,args.donor_dir,args.checkpoint,args.output)
        print('TTM_EMBED_SWAP_REAL_BUILD='+report['status'])
        print(json.dumps(report,sort_keys=True))

if __name__=='__main__':
    main()
