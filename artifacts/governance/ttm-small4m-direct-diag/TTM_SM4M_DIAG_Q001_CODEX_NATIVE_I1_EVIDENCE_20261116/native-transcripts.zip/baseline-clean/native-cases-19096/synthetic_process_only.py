import os,subprocess,sys,time
mode=sys.argv[1]
if mode=="normal": print("OK",flush=True)
elif mode=="exit_big":
 sys.stdout.buffer.write(b"X"*65536); sys.stdout.buffer.flush()
elif mode=="stall": time.sleep(8)
elif mode=="child":
 data=bytearray(90*1024*1024)
 with open(sys.argv[2],"w") as f: f.write(str(os.getpid()))
 time.sleep(8)
elif mode in ("parent_child","parent_exit_child"):
 child=subprocess.Popen([sys.executable,__file__,"child",sys.argv[2]])
 time.sleep(.8 if mode=="parent_exit_child" else 8)
else: sys.exit(13)
