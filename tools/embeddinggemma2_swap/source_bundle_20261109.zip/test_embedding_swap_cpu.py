"""Small, independent CPU-only test surface for TTM input embedding replacement.

Synthetic donor embeddings only. Not a quality benchmark or real pretrained test.
"""
from __future__ import annotations
import importlib.util
from pathlib import Path
import tempfile
import unittest
import torch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('swap', HERE/'ttm_embeddinggemma2_swap.py')
swap = importlib.util.module_from_spec(spec)
assert spec.loader
spec.loader.exec_module(swap)

class FakeDonorTable:
    shape = (262144, 512)
    def __getitem__(self, keys):
        if isinstance(keys, int):
            keys = [keys]
        return torch.stack([torch.full((512,), float(k) / 1000) for k in keys])

class FakeTokenizer:
    all_special_ids = [2, 42]
    def encode(self, text, add_special_tokens=True):
        if add_special_tokens:
            raise AssertionError('BOS_OR_EOS_INJECTION_FORBIDDEN')
        if text == 'bad-special':
            return [2]
        if text == 'nope':
            return []
        if text == 'multitoken':
            return [123, 124]
        return [314]

class SwapTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)
        cls.p02 = swap.load_p02(HERE/'p02_exact.py')

    def test_01_p02_exact_sha(self):
        self.assertEqual(swap.sha256(HERE/'p02_exact.py'), swap.P02_SHA256)

    def test_02_original_real_config(self):
        m = self.p02.GPT(swap.p02_config(self.p02))
        self.assertEqual(sum(x.numel() for x in m.parameters()), 3749376)
        self.assertEqual(m.tok.weight.shape, (2048,256))
        self.assertEqual(m.head.weight.data_ptr(),m.tok.weight.data_ptr())

    def test_03_detach_head_no_numerical_change(self):
        torch.manual_seed(1)
        m=self.p02.GPT(swap.p02_config(self.p02)).eval()
        out=swap.control_untied(m).eval()
        x=torch.randint(0,2048,(1,5))
        with torch.no_grad():
            self.assertTrue(torch.equal(m(x)[0],out(x)[0]))
        self.assertNotEqual(out.tok.weight.data_ptr(),out.head.weight.data_ptr())

    def test_04_swap_rejects_eos_mapping(self):
        a=torch.zeros(2048,512);valid=torch.zeros(2048,dtype=torch.bool)
        valid[256]=True
        with self.assertRaisesRegex(ValueError,'EOS_MUST'):
            swap.MappedGemmaInput(a,valid,torch.zeros(2048,256),torch.zeros(256,512))

    def test_05_swap_rejects_wrong_shapes(self):
        with self.assertRaisesRegex(ValueError,'SHAPES'):
            swap.MappedGemmaInput(torch.zeros(2048,768),torch.zeros(2048,dtype=torch.bool),torch.zeros(2048,256),torch.zeros(256,512))

    def test_06_swap_rejects_nan(self):
        a=torch.zeros(2048,512);a[10,10]=float('nan')
        with self.assertRaisesRegex(ValueError,'NONFINITE'):
            swap.MappedGemmaInput(a,torch.zeros(2048,dtype=torch.bool),torch.zeros(2048,256),torch.zeros(256,512))

    def test_07_bpe_bytes_utf8_partial_fallback(self):
        b=swap.byte_to_unicode()
        tokens=[b[x] for x in range(256)]+['<|endoftext|>']+['token_'+str(i) for i in range(257,2048)]
        tokens[300]='multitoken'
        tokens[301]='bad-special'
        tokens[302]='nope'
        rows,mask,c = swap.map_bpe_tokens(tokens,FakeTokenizer(),FakeDonorTable())
        self.assertFalse(bool(mask[195]))  # UTF-8 start byte alone, invalid
        self.assertFalse(bool(mask[256]))  # TTM end of story, original row
        self.assertTrue(bool(mask[300]))
        self.assertFalse(bool(mask[301]))
        self.assertFalse(bool(mask[302]))
        self.assertTrue(torch.allclose(rows[300],torch.full((512,), .1235)))
        self.assertGreater(c['incomplete_utf8'],0)
        self.assertGreater(c['multi_id_mapped'],0)

    def test_08_bpe_wrong_vocab_negative(self):
        with self.assertRaisesRegex(ValueError,'TTM_VOCAB'):
            swap.map_bpe_tokens(['a'],FakeTokenizer(),FakeDonorTable())

    def test_09_donor_wrong_shape_negative(self):
        tokens=['A']*2048;tokens[256]='<|endoftext|>'
        with self.assertRaisesRegex(ValueError,'DONOR_TOKEN_TABLE'):
            swap.map_bpe_tokens(tokens,FakeTokenizer(),torch.zeros(256,768))

    def test_10_ridge_rejects_few_rows(self):
        mask=torch.zeros(2048,dtype=torch.bool);mask[:100]=True
        with self.assertRaisesRegex(ValueError,'INSUFFICIENT_MAPPABLE'):
            swap.ridge_align(torch.zeros(2048,512),mask,torch.zeros(2048,256))

    def test_11_no_original_model_mutation(self):
        m=self.p02.GPT(swap.p02_config(self.p02))
        before={k:x.clone() for k,x in m.state_dict().items()}
        mask=torch.ones(2048,dtype=torch.bool);mask[256]=False
        rng=torch.Generator().manual_seed(99)
        donor=torch.randn((2048,512),generator=rng)
        candidate=swap.build_swap(m,donor,mask)
        self.assertIsInstance(candidate.tok,swap.MappedGemmaInput)
        self.assertTrue(all(torch.equal(v,m.state_dict()[k]) for k,v in before.items()))

    def test_12_untied_candidate_gradient(self):
        m=self.p02.GPT(swap.p02_config(self.p02))
        mask=torch.ones(2048,dtype=torch.bool);mask[256]=False
        gen=torch.Generator().manual_seed(1)
        candidate=swap.build_swap(m,torch.randn((2048,512),generator=gen),mask)
        x=torch.tensor([[1,2,3,4,5,6]],dtype=torch.long)
        _,loss=candidate(x,x)
        loss.backward()
        self.assertTrue(torch.isfinite(candidate.tok.proj.weight.grad).all())
        self.assertIsNone(candidate.tok.source.weight.grad)
        self.assertIsNotNone(candidate.head.weight.grad)

    def test_13_no_implicit_network_or_science_in_cpu_smoke(self):
        text=(HERE/'ttm_embeddinggemma2_swap.py').read_text()
        self.assertNotIn('snapshot_download(',text)
        self.assertNotIn('from_pretrained("google/embeddinggemma-2"',text)
        self.assertNotIn('load_dataset(',text)

    def test_14_refuse_bad_p02_pin(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'wrong.py';p.write_text('x=1')
            with self.assertRaisesRegex(RuntimeError,'SHA256'):
                swap.load_p02(p)

    def test_15_full_structural_proof(self):
        r=swap.cpu_smoke(HERE/'p02_exact.py')
        self.assertEqual(r['verdict'],'PASS_CPU_SYNTHETIC_STRUCTURE_ONLY')
        self.assertFalse(r['gpu_used'])
        self.assertFalse(r['real_donor_data_used'])

if __name__ == '__main__':
    unittest.main(verbosity=2)
