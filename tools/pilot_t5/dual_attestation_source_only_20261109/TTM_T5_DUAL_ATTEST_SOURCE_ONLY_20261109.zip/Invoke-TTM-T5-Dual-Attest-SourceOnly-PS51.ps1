param()
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = 'D:\WORK\RESEARCH\TokenToModel-Lab'
$expectedFolder = 'TTM_T5_DUAL_ATTEST_SOURCE_ONLY_20261109'
$source = Split-Path -Parent $MyInvocation.MyCommand.Path
$sourceExpected = Join-Path (Join-Path $root '_tmp') $expectedFolder
$python = 'C:\Users\minht\AppData\Local\Programs\Python\Python312\python.exe'
if (-not ([string]::Equals($source,$sourceExpected,[System.StringComparison]::OrdinalIgnoreCase))) { throw 'SOURCE_NOT_IN_PROJECT_LOCAL_EXACT_DIRECTORY' }
if (-not (Test-Path -LiteralPath (Join-Path $root '.git'))) { throw 'TTM_PROJECT_ROOT_MISSING' }
if (-not (Test-Path -LiteralPath $python -PathType Leaf)) { throw 'PYTHON312_PIN_MISSING' }
if (Test-Path -LiteralPath (Join-Path (Join-Path $root '_tmp') 'ttm_t5_ollama_compat_only_single_dual_rc2')) { throw 'RC2_OUTPUT_ALREADY_EXISTS_NO_OVERWRITE' }
$manifest = Join-Path $source 'SOURCE_SHA256_MANIFEST.json'
if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) { throw 'SOURCE_MANIFEST_MISSING' }
$pin = Get-Content -LiteralPath $manifest -Raw | ConvertFrom-Json
if ($pin.schema -cne 'ttm.t5.dual_attest.source_only.manifest.v1') { throw 'MANIFEST_SCHEMA_INVALID' }
foreach ($entry in $pin.sha256.PSObject.Properties) {
    if ($entry.Name -notmatch '^[A-Za-z0-9_.-]+$') { throw 'UNSAFE_MANIFEST_FILENAME' }
    $path = Join-Path $source $entry.Name
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw "MISSING_SOURCE:$($entry.Name)" }
    $real = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($real -cne ([string]$entry.Value).ToLowerInvariant()) { throw "SOURCE_HASH_MISMATCH:$($entry.Name)" }
}
Write-Host 'TTM_T5_DUAL_SOURCE_SHA256=PASS'
$env:PYTHONDONTWRITEBYTECODE = '1'
$src = Join-Path $source 't5_dual_attest_rc2_candidate.py'
$check = Join-Path $source 'test_independent_dual_attest.py'
& $python -B $src --mode contract
if ($LASTEXITCODE -ne 0) { throw 'DUAL_CONTRACT_FAILED' }
Write-Host 'TTM_T5_DUAL_RUNTIME=LOCKED_NOT_EXECUTED'
& $python -B $check
if ($LASTEXITCODE -ne 0) { throw 'DUAL_OFFLINE_QA_FAILED' }
Write-Host 'TTM_T5_DUAL_WINDOWS_STATIC_QA=PASS_114_OF_114'
Write-Host 'TTM_T5_DUAL_OLLAMA_REAL_RUNTIME=NOT_EXECUTED'
Write-Host 'TTM_T5_DUAL_V1_V2_RC1=CONSUMED_PRESERVED'
Write-Host 'TTM_T5_DUAL_STRICT_PARITY=FAIL_7_OF_8_PRESERVED'
