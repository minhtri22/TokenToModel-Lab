# TTM T5 — Xác minh kép PID + HTTP (Dual Attestation) — SOURCE ONLY

Ngày 2026-11-09. Đây là bản sửa nguồn cho nhánh `research/ttm-small-4m-colab-pilot-prereg-20261108`, **không phải bộ được phép chạy Ollama thực tế**.

## Nội dung
- `t5_native_tcp.py`: đọc hai bảng TCP IPv4/IPv6 bằng Windows IP Helper và phân tích cú pháp có giới hạn. Trạng thái TCP `0` giữ nguyên là **UNKNOWN**, không bao giờ được đổi thành `LISTEN=2`.
- `t5_dual_attest_rc2_candidate.py`: mã nguồn ứng viên kế nhiệm RC2; cổng riêng **12646**, kho bằng chứng riêng `_tmp\ttm_t5_ollama_compat_only_single_dual_rc2`. `--mode contract` là chế độ CLI duy nhất. `--mode execute` bị từ chối; hàm chạy nội bộ cũng có khóa cứng `SOURCE_ONLY_EXECUTION_LOCK=True`.
- `test_independent_dual_attest.py`: 114 bài QA giả lập, gồm parser, IPv4/IPv6, quá trình xác minh kép PID–HTTP, các trường hợp từ chối và mô phỏng trọn chuỗi `serve → create → manifest → generate` **không có Ollama thực**.
- `Invoke-TTM-T5-Dual-Attest-SourceOnly-PS51.ps1`: xác thực hash mã nguồn và chạy 114 bài QA trên Windows 11/PowerShell 5.1/Python 3.12. Không có lệnh khởi chạy Ollama.
- `SOURCE_SHA256_MANIFEST.json`, `INDEPENDENT_OFFLINE_QA.json`: chứng cứ và SHA nguồn.

## Giới hạn quyết định
1. Mọi socket trên cổng mới phải thuộc đúng PID mới tạo, tiến trình `ollama.exe` đúng đường dẫn; danh tính và thời điểm tạo phải giữ nguyên trước/sau HTTP.
2. Chỉ chấp nhận địa chỉ cục bộ `127.0.0.1` hoặc `::1`, không chấp nhận `0.0.0.0`, `::`, địa chỉ LAN, PID lạ hoặc nhiều PID.
3. Với `State=0`, chỉ xem là **ứng viên** nếu địa chỉ/cổng đầu xa bằng không; **không đánh dấu LISTEN**. Sau đó HTTP không qua proxy phải trả `200`, phiên bản `0.40.14`, rồi snapshot thứ hai phải khớp. Nếu không = HOLD.
4. Địa chỉ có socket `State=2` vẫn phải qua cùng quy trình HTTP/identity, không chỉ dựa vào trạng thái TCP.
5. Bảo toàn V1, V2, V3 RC1 **CONSUMED**, GGUF SHA `5bdc904e6c51af04a4223219f36e6bc2e687f60fd6e17dc24508f3eb7489e4e5`, T5 strict parity **FAIL 7/8**.
6. Các mô phỏng `create`/`generate` trong unit test là fake, không thể coi là kết quả Ollama thực tế. Chưa có phán quyết tương thích TTM-Small-4M.

## Cách chạy kiểm định tĩnh trên Windows (chưa bắt buộc trong bước thiết kế)
Chỉ sau khi xác minh SHA-256 của ZIP đã công bố và giải nén tại đúng thư mục:
`D:\WORK\RESEARCH\TokenToModel-Lab\_tmp\TTM_T5_DUAL_ATTEST_SOURCE_ONLY_20261109`

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File 'D:\WORK\RESEARCH\TokenToModel-Lab\_tmp\TTM_T5_DUAL_ATTEST_SOURCE_ONLY_20261109\Invoke-TTM-T5-Dual-Attest-SourceOnly-PS51.ps1'
```

Không chạy `--mode execute`, không chạy lại V1/V2/RC1, không xóa bằng chứng cũ. Không thay đổi `lineage.md` hoặc Git `main`.

## Bước tiếp theo
`TTM_T5_DUAL_ATTEST_WINDOWS_STATIC_QA_READBACK_AND_ONE_GUARDED_RELEASE_DECISION` — kiểm tra SHA/QA native Windows **một lần**, sau đó quyết định một bản phát hành runtime có khóa SHA riêng. Chưa cấp phép lượt Ollama mới trong gói này.
