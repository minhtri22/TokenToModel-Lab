#!/usr/bin/env python3
"""Independent pure-fixture / mocked-transport QA for TTM dual attestation.

No real Windows native API, PowerShell, Ollama, socket connection, model import,
training data access or network call. On Windows fixtures stay inside project _tmp.
"""
from __future__ import annotations
import ast
import contextlib
import ctypes
import importlib
import json
from pathlib import Path
import socket
import struct
import subprocess
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch, Mock

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
m=importlib.import_module('t5_dual_attest_rc2_candidate')
n=importlib.import_module('t5_native_tcp')
PID=24680
DATE='2026-11-09T01:00:00Z'

class Proc:
    def __init__(self,pid=PID,rc=None):self.pid=pid;self.rc=rc;self.returncode=rc
    def poll(self):return self.rc


def row(fam='IPv4',addr='127.0.0.1',state=0,pid=PID,port=None,remote=None,remote_port=0):
    if port is None:port=m.PORT
    if fam=='IPv6' and addr=='127.0.0.1':addr='::1'
    if remote is None: remote='0.0.0.0' if fam=='IPv4' else '::'
    return {'address_family':fam,'local_address':addr,'local_port':port,
            'remote_address':remote,'remote_port':remote_port,'pid':pid,
            'state_code':state,'state_verified_listen':state==2}

def identity(pid=PID,creation=DATE,path=None,name='ollama.exe'):
    return {'pid':pid,'name':name,'executable_path':str(m.EXE) if path is None else path,'creation_date':creation}

def snapshot(rows=None,processes=None,port=None,families=None):
    return {'schema':'ttm.t5.native.tcptable.dual.v1',
            'port':m.PORT if port is None else port,
            'rows':[row()] if rows is None else rows,
            'processes':[identity()] if processes is None else processes,
            'families_queried':['IPv4','IPv6'] if families is None else families}

def good_http(_):
    return {'attempted':True,'http_status':200,'api_version':m.VERSION,
            'error_type':None,'error_code':None}

class Sequence:
    def __init__(self,*items):self.items=list(items);self.i=0
    def __call__(self,p):
        if p!=m.PORT:raise AssertionError('WRONG_PORT')
        i=self.i;self.i+=1
        if i>=len(self.items):raise AssertionError('NO_MORE_SNAPSHOTS')
        item=self.items[i]
        if isinstance(item,Exception):raise item
        return item

@contextlib.contextmanager
def fixture_dir():
    if sys.platform=='win32':
        root=Path(r'D:\WORK\RESEARCH\TokenToModel-Lab\_tmp')
        if not root.is_dir():raise RuntimeError('QA_PROJECT_LOCAL_TMP_MISSING')
    else:root=HERE
    with tempfile.TemporaryDirectory(prefix='ttm_dual_qa_',dir=str(root)) as path:
        yield Path(path)

def packet4(state=0,addr='127.0.0.1',remote='0.0.0.0',port=None,pid=PID,remote_port=0):
    if port is None:port=m.PORT
    r=n.Tcp4Row();r.state=state;r.pid=pid
    r.local_addr=int.from_bytes(socket.inet_aton(addr),sys.byteorder)
    r.remote_addr=int.from_bytes(socket.inet_aton(remote),sys.byteorder)
    r.local_port=socket.htons(port);r.remote_port=socket.htons(remote_port)
    return bytes(r)

def packet6(state=0,addr='::1',remote='::',port=None,pid=PID,remote_port=0):
    if port is None:port=m.PORT
    r=n.Tcp6Row();r.state=state;r.pid=pid
    for i,b in enumerate(socket.inet_pton(socket.AF_INET6,addr)):r.local_addr[i]=b
    for i,b in enumerate(socket.inet_pton(socket.AF_INET6,remote)):r.remote_addr[i]=b
    r.local_port=socket.htons(port);r.remote_port=socket.htons(remote_port)
    return bytes(r)

def table(*rows):return struct.pack('<I',len(rows))+b''.join(rows)

class TestNativeParser(unittest.TestCase):
    def test_layout_pins(self):n.validate_layout();self.assertEqual(ctypes.sizeof(n.Tcp6Row),56)
    def test_ipv4_state_zero_raw(self):
        x=n.parse_table(table(packet4()),n.AF_INET,m.PORT)[0]
        self.assertEqual((x['state_code'],x['state_verified_listen'],x['remote_port']),(0,False,0))
    def test_ipv4_listen_two(self):self.assertTrue(n.parse_table(table(packet4(state=2)),n.AF_INET,m.PORT)[0]['state_verified_listen'])
    def test_ipv4_remote_nonzero(self):
        x=n.parse_table(table(packet4(remote='127.0.0.1',remote_port=51344)),n.AF_INET,m.PORT)[0]
        self.assertEqual((x['remote_address'],x['remote_port']),('127.0.0.1',51344))
    def test_ipv4_wildcard(self):self.assertEqual(n.parse_table(table(packet4(addr='0.0.0.0')),n.AF_INET,m.PORT)[0]['local_address'],'0.0.0.0')
    def test_ipv4_state_established(self):self.assertEqual(n.parse_table(table(packet4(state=5)),n.AF_INET,m.PORT)[0]['state_code'],5)
    def test_ipv6_state_zero(self):self.assertEqual(n.parse_table(table(packet6()),n.AF_INET6,m.PORT)[0]['state_code'],0)
    def test_ipv6_listen(self):self.assertEqual(n.parse_table(table(packet6(state=2)),n.AF_INET6,m.PORT)[0]['local_address'],'::1')
    def test_ipv6_remote_nonzero(self):
        x=n.parse_table(table(packet6(remote='::1',remote_port=12345)),n.AF_INET6,m.PORT)[0]
        self.assertEqual((x['remote_address'],x['remote_port']),('::1',12345))
    def test_other_port_ignored(self):self.assertEqual(n.parse_table(table(packet4(port=11434)),n.AF_INET,m.PORT),[])
    def test_empty_table(self):self.assertEqual(n.parse_table(table(),n.AF_INET,m.PORT),[])
    def test_too_short(self):
        with self.assertRaises(ValueError):n.parse_table(b'\x00',n.AF_INET,m.PORT)
    def test_count_overflow(self):
        with self.assertRaises(ValueError):n.parse_table(struct.pack('<I',2)+packet4(),n.AF_INET,m.PORT)
    def test_excessive_count(self):
        with self.assertRaises(ValueError):n.parse_table(struct.pack('<I',n.MAX_ENTRIES+1),n.AF_INET,m.PORT)
    def test_wrong_family(self):
        with self.assertRaises(ValueError):n.parse_table(table(packet4()),999,m.PORT)
    def test_wrong_port_type_bool(self):
        with self.assertRaises(ValueError):n.parse_table(table(),n.AF_INET,True)
    def test_wrong_port_zero(self):
        with self.assertRaises(ValueError):n.parse_table(table(),n.AF_INET,0)
    def test_capture_both_families(self):
        fake=lambda af:table(packet4()) if af==n.AF_INET else table(packet6())
        z=n.capture(m.PORT,native_fn=fake)
        self.assertEqual((len(z['rows']),z['families_queried']),(2,['IPv4','IPv6']))
    def test_capture_ipv4_failure_holds(self):
        with self.assertRaises(RuntimeError):n.capture(m.PORT,native_fn=lambda af:(_ for _ in ()).throw(RuntimeError('FAILED')))
    def test_capture_ipv6_failure_holds(self):
        def fake(af):
            if af==n.AF_INET6:raise RuntimeError('FAILED')
            return table(packet4())
        with self.assertRaises(RuntimeError):n.capture(m.PORT,native_fn=fake)
    def test_native_api_rejected_off_windows(self):
        with patch.object(n.sys,'platform','linux'):
            with self.assertRaisesRegex(RuntimeError,'NATIVE_WINDOWS_ONLY'):n.native_table(n.AF_INET)

class TestPureOwnership(unittest.TestCase):
    def chk(self, x, expected,creation=None):
        y=m.ownership_status(x,PID,expected_creation=creation)
        self.assertEqual(y['decision'],expected)
        return y
    def test_state_zero_is_candidate_not_listen(self):
        z=self.chk(snapshot(),'OWNED_LOOPBACK_CANDIDATE_ONLY')
        self.assertEqual((z['unknown_state_count'],z['confirmed_listen_count']),(1,0))
    def test_state_two_is_confirmed(self):
        z=self.chk(snapshot(rows=[row(state=2)]),'OWNED_LOOPBACK_CANDIDATE_ONLY')
        self.assertEqual(z['confirmed_listen_count'],1)
    def test_ipv6_zero_candidate(self):self.chk(snapshot(rows=[row(fam='IPv6')]),'OWNED_LOOPBACK_CANDIDATE_ONLY')
    def test_both_families_same_pid(self):self.chk(snapshot(rows=[row(),row(fam='IPv6')]),'OWNED_LOOPBACK_CANDIDATE_ONLY')
    def test_mixed_zero_and_two(self):self.chk(snapshot(rows=[row(),row(fam='IPv6',state=2)]),'OWNED_LOOPBACK_CANDIDATE_ONLY')
    def test_wildcard_v4_rejected(self):self.chk(snapshot(rows=[row(addr='0.0.0.0')]),'HOLD_NON_LOOPBACK_OR_WILDCARD')
    def test_wildcard_v6_rejected(self):self.chk(snapshot(rows=[row(fam='IPv6',addr='::')]),'HOLD_NON_LOOPBACK_OR_WILDCARD')
    def test_lan_address_rejected(self):self.chk(snapshot(rows=[row(addr='192.168.10.5')]),'HOLD_NON_LOOPBACK_OR_WILDCARD')
    def test_ipv4_mapped_ipv6_rejected(self):self.chk(snapshot(rows=[row(fam='IPv6',addr='::ffff:127.0.0.1')]),'HOLD_NON_LOOPBACK_OR_WILDCARD')
    def test_untrusted_pid_rejected(self):self.chk(snapshot(rows=[row(pid=1)]),'HOLD_UNTRUSTED_PID')
    def test_multiple_pids_rejected(self):self.chk(snapshot(rows=[row(),row(fam='IPv6',pid=55)]),'HOLD_UNTRUSTED_PID')
    def test_duplicate_socket_rejected(self):self.chk(snapshot(rows=[row(),row()]),'HOLD_DUPLICATE_CANDIDATE')
    def test_state_zero_nonzero_remote_port_rejected(self):self.chk(snapshot(rows=[row(remote_port=41235)]),'HOLD_STATE_ZERO_WITH_NONZERO_REMOTE')
    def test_state_zero_nonzero_remote_addr_rejected(self):self.chk(snapshot(rows=[row(remote='127.0.0.1')]),'HOLD_STATE_ZERO_WITH_NONZERO_REMOTE')
    def test_state_zero_ipv6_remote_rejected(self):self.chk(snapshot(rows=[row(fam='IPv6',remote='::1')]),'HOLD_STATE_ZERO_WITH_NONZERO_REMOTE')
    def test_state_other_99_rejected(self):self.chk(snapshot(rows=[row(state=99)]),'HOLD_INVALID_TCP_STATE_CODE')
    def test_established_only_never_candidate(self):self.chk(snapshot(rows=[row(state=5,remote='127.0.0.1',remote_port=50000)],processes=[]),'WAIT_NO_CANDIDATE_SOCKET')
    def test_established_same_pid_additional_allowed(self):self.chk(snapshot(rows=[row(),row(state=5,remote='127.0.0.1',remote_port=40000)]),'OWNED_LOOPBACK_CANDIDATE_ONLY')
    def test_any_wildcard_transient_rejected(self):self.chk(snapshot(rows=[row(),row(state=5,addr='0.0.0.0')]),'HOLD_NON_LOOPBACK_OR_WILDCARD')
    def test_malformed_missing_state(self):
        x=snapshot();del x['rows'][0]['state_code'];self.chk(x,'HOLD_TCP_ROW_MALFORMED')
    def test_malformed_pid_boolean(self):self.chk(snapshot(rows=[row(pid=True)]),'HOLD_TCP_ROW_MALFORMED')
    def test_malformed_remote_port(self):self.chk(snapshot(rows=[row(remote_port=-1)]),'HOLD_TCP_ROW_MALFORMED')
    def test_incorrect_port(self):self.chk(snapshot(rows=[row(port=11434)]),'HOLD_TCP_ROW_MALFORMED')
    def test_snapshot_schema_rejected(self):
        x=snapshot();x['schema']='other';self.chk(x,'HOLD_TCP_TABLE_MALFORMED')
    def test_family_missing_rejected(self):self.chk(snapshot(families=['IPv4']),'HOLD_TCP_TABLE_MALFORMED')
    def test_no_candidate_wait(self):self.chk(snapshot(rows=[],processes=[]),'WAIT_NO_CANDIDATE_SOCKET')
    def test_missing_process_holds(self):self.chk(snapshot(processes=[]),'HOLD_OWNER_IDENTITY_MISSING')
    def test_multiple_processes_holds(self):self.chk(snapshot(processes=[identity(),identity()]),'HOLD_TCP_TABLE_MALFORMED')
    def test_wrong_path_rejected(self):self.chk(snapshot(processes=[identity(path=r'C:\fake\ollama.exe')]),'HOLD_OWNER_EXECUTABLE_MISMATCH')
    def test_wrong_name_rejected(self):self.chk(snapshot(processes=[identity(name='python.exe')]),'HOLD_OWNER_EXECUTABLE_MISMATCH')
    def test_wrong_process_pid_rejected(self):self.chk(snapshot(processes=[identity(pid=42)]),'HOLD_OWNER_EXECUTABLE_MISMATCH')
    def test_missing_creation_date(self):self.chk(snapshot(processes=[identity(creation='')]),'HOLD_PROCESS_CREATION_MISSING')
    def test_creation_mismatch_rejected(self):self.chk(snapshot(),'HOLD_PROCESS_REPLACED',creation='DIFFERENT')
    def test_creation_match_pass(self):self.chk(snapshot(),'OWNED_LOOPBACK_CANDIDATE_ONLY',creation=DATE)
    def test_boolean_process_pid_rejected(self):self.chk(snapshot(processes=[identity(pid=True)]),'HOLD_OWNER_EXECUTABLE_MISMATCH')
    def test_malformed_snapshot_list(self):self.chk({'schema':'ttm.t5.native.tcptable.dual.v1','port':m.PORT,'rows':None,'processes':[],'families_queried':['IPv4','IPv6']},'HOLD_TCP_TABLE_MALFORMED')

class TestDualHttpAndTrace(unittest.TestCase):
    def sample(self,before=None,after=None,http_fn=good_http,process=None):
        if before is None:before=snapshot()
        if after is None:after=before
        return m.readiness_sample(Proc() if process is None else process,1,
                                  tcp_fn=Sequence(before,after),http_fn=http_fn)
    def test_positive_state_zero(self):
        x=self.sample();self.assertEqual(x['decision'],'READY_DUAL_ATTESTED_STATE_ZERO_UNKNOWN')
        self.assertFalse(x['attestation']['native_listen_confirmed'])
    def test_positive_state_two(self):
        x=self.sample(before=snapshot(rows=[row(state=2)]))
        self.assertEqual(x['decision'],'READY_DUAL_ATTESTED_VERIFIED_LISTEN')
    def test_positive_ipv6_state_zero(self):self.assertEqual(self.sample(before=snapshot(rows=[row(fam='IPv6')]))['decision'],'READY_DUAL_ATTESTED_STATE_ZERO_UNKNOWN')
    def test_positive_both_families(self):self.assertEqual(self.sample(before=snapshot(rows=[row(),row(fam='IPv6')]))['decision'],'READY_DUAL_ATTESTED_STATE_ZERO_UNKNOWN')
    def test_no_owner_never_http(self):
        http=Mock(side_effect=AssertionError('SHOULD_NOT_CONNECT'))
        x=self.sample(before=snapshot(rows=[],processes=[]),http_fn=http)
        self.assertEqual(x['decision'],'WAIT_NO_CANDIDATE_SOCKET');http.assert_not_called()
    def test_wrong_pid_never_http(self):
        http=Mock(side_effect=AssertionError('SHOULD_NOT_CONNECT'))
        x=self.sample(before=snapshot(rows=[row(pid=10)]),http_fn=http)
        self.assertEqual(x['decision'],'HOLD_UNTRUSTED_PID');http.assert_not_called()
    def test_wildcard_never_http(self):
        http=Mock(side_effect=AssertionError('SHOULD_NOT_CONNECT'))
        x=self.sample(before=snapshot(rows=[row(addr='0.0.0.0')]),http_fn=http)
        self.assertEqual(x['decision'],'HOLD_NON_LOOPBACK_OR_WILDCARD');http.assert_not_called()
    def test_unknown_remote_never_http(self):
        http=Mock(side_effect=AssertionError('SHOULD_NOT_CONNECT'))
        x=self.sample(before=snapshot(rows=[row(remote_port=5)]),http_fn=http)
        self.assertEqual(x['decision'],'HOLD_STATE_ZERO_WITH_NONZERO_REMOTE');http.assert_not_called()
    def test_http_503_waits(self):
        x=self.sample(http_fn=lambda _:{**good_http(_),'http_status':503})
        self.assertEqual(x['decision'],'WAIT_HTTP_NO_200')
    def test_http_wrong_version_waits(self):
        x=self.sample(http_fn=lambda _:{**good_http(_),'api_version':'0.39.0'})
        self.assertEqual(x['decision'],'WAIT_HTTP_INVALID_OR_WRONG_VERSION')
    def test_http_malformed_waits(self):
        x=self.sample(http_fn=lambda _:{**good_http(_),'error_code':'INVALID_JSON'})
        self.assertEqual(x['decision'],'WAIT_HTTP_INVALID_OR_WRONG_VERSION')
    def test_http_invalid_shape_holds(self):self.assertEqual(self.sample(http_fn=lambda _:[])['decision'],'HOLD_HTTP_PROBE_INVALID')
    def test_http_exception_captured(self):
        def bad(_):raise TimeoutError('SECRET_HOST')
        x=self.sample(http_fn=bad);self.assertEqual(x['decision'],'WAIT_HTTP_EXCEPTION')
        self.assertNotIn('SECRET_HOST',json.dumps(x))
    def test_recheck_pid_changed(self):self.assertEqual(self.sample(after=snapshot(rows=[row(pid=18)]))['decision'],'HOLD_OWNER_CHANGED_AFTER_HTTP')
    def test_recheck_creation_changed(self):self.assertEqual(self.sample(after=snapshot(processes=[identity(creation='DIFFERENT')]))['decision'],'HOLD_OWNER_CHANGED_AFTER_HTTP')
    def test_recheck_state_changed(self):self.assertEqual(self.sample(after=snapshot(rows=[row(state=2)]))['decision'],'HOLD_CANDIDATE_CHANGED_AFTER_HTTP')
    def test_recheck_address_changed(self):self.assertEqual(self.sample(after=snapshot(rows=[row(fam='IPv6')]))['decision'],'HOLD_CANDIDATE_CHANGED_AFTER_HTTP')
    def test_recheck_table_error_holds(self):
        x=m.readiness_sample(Proc(),1,tcp_fn=Sequence(snapshot(),RuntimeError('bad table')),http_fn=good_http)
        self.assertEqual(x['decision'],'HOLD_NATIVE_RECHECK_UNAVAILABLE')
    def test_initial_table_error_holds_and_skips_http(self):
        http=Mock(side_effect=AssertionError('HTTP CALLED'))
        x=m.readiness_sample(Proc(),1,tcp_fn=Sequence(RuntimeError('unavailable')),http_fn=http)
        self.assertEqual(x['decision'],'HOLD_NATIVE_TCP_OR_IDENTITY_UNAVAILABLE');http.assert_not_called()
    def test_exit_before_probe(self):
        http=Mock(side_effect=AssertionError('HTTP CALLED'))
        x=m.readiness_sample(Proc(rc=4),1,tcp_fn=Mock(side_effect=AssertionError('TABLE CALLED')),http_fn=http)
        self.assertEqual(x['decision'],'FAIL_SERVER_EXITED');http.assert_not_called()
    def test_exit_after_http(self):
        p=Proc()
        def probe(_):p.rc=5;return good_http(_)
        x=m.readiness_sample(p,1,tcp_fn=Sequence(snapshot()),http_fn=probe)
        self.assertEqual(x['decision'],'FAIL_SERVER_EXITED_AFTER_HTTP')
    def test_pinned_api_url(self):
        observed=[]
        self.sample(http_fn=lambda url:(observed.append(url) or good_http(url)))
        self.assertEqual(observed,[m.API+'/api/version'])
    def test_expected_creation_mismatch_before_http(self):
        http=Mock(side_effect=AssertionError('HTTP CALLED'))
        x=m.readiness_sample(Proc(),1,tcp_fn=Sequence(snapshot()),http_fn=http,expected_creation='FAKE')
        self.assertEqual(x['decision'],'HOLD_PROCESS_REPLACED');http.assert_not_called()
    def test_http_200_alone_not_accepted(self):
        x=self.sample(before=snapshot(rows=[],processes=[]))
        self.assertNotIn('READY',x['decision'])
    def test_fsync_durable_success(self):
        with fixture_dir() as d:
            z=m.observe_readiness_with_trace(Proc(),d,tcp_fn=Sequence(snapshot(),snapshot()),http_fn=good_http,sleep_fn=lambda _:None,max_samples=1)
            self.assertTrue(z['ready']);self.assertEqual(z['samples'],1)
            raw=(d/'READINESS_ATTEMPTS.jsonl').read_text()
            self.assertEqual(json.loads(raw)['decision'],'READY_DUAL_ATTESTED_STATE_ZERO_UNKNOWN')
    def test_fsync_timeout_no_http(self):
        with fixture_dir() as d:
            http=Mock(side_effect=AssertionError('NO HTTP'))
            with self.assertRaisesRegex(RuntimeError,'READINESS_TIMEOUT'):
                m.observe_readiness_with_trace(Proc(),d,tcp_fn=Sequence(snapshot(rows=[],processes=[]),snapshot(rows=[],processes=[])),http_fn=http,sleep_fn=lambda _:None,max_samples=2)
            self.assertEqual(len((d/'READINESS_ATTEMPTS.jsonl').read_text().splitlines()),2)
            http.assert_not_called()
    def test_trace_no_overwrite(self):
        with fixture_dir() as d:
            (d/'READINESS_ATTEMPTS.jsonl').write_text('BEFORE\n')
            with self.assertRaises(FileExistsError):m.observe_readiness_with_trace(Proc(),d,max_samples=1)
            self.assertEqual((d/'READINESS_ATTEMPTS.jsonl').read_text(),'BEFORE\n')
    def test_hold_first_sample_preserved(self):
        with fixture_dir() as d:
            with self.assertRaisesRegex(RuntimeError,'READINESS_HOLD_UNTRUSTED_PID'):
                m.observe_readiness_with_trace(Proc(),d,tcp_fn=Sequence(snapshot(rows=[row(pid=333)])),http_fn=good_http,max_samples=1)
            self.assertEqual(len((d/'READINESS_ATTEMPTS.jsonl').read_text().splitlines()),1)

class TestRuntimeLockAndContracts(unittest.TestCase):
    def test_cli_contract_only(self):
        p=subprocess.run([sys.executable,'-B',str(HERE/'t5_dual_attest_rc2_candidate.py'),'--mode','contract'],capture_output=True,text=True,check=True)
        self.assertIn('EXECUTION_LOCK=ACTIVE_NO_RUNTIME_PERMIT',p.stdout)
    def test_cli_execute_rejected_without_runtime(self):
        p=subprocess.run([sys.executable,'-B',str(HERE/'t5_dual_attest_rc2_candidate.py'),'--mode','execute'],capture_output=True,text=True)
        self.assertNotEqual(p.returncode,0)
        self.assertIn('invalid choice',p.stderr)
    def test_execute_locked_before_any_write_or_process(self):
        with patch.object(m,'new_dir',side_effect=AssertionError('WRITE')),patch.object(m.subprocess,'Popen',side_effect=AssertionError('Popen')):
            with self.assertRaisesRegex(RuntimeError,'SOURCE_ONLY_NO_RUNTIME_PERMIT'):
                m.execute({})
    def test_no_netstat_or_net_tcp_in_source(self):
        text=(HERE/'t5_dual_attest_rc2_candidate.py').read_text()
        self.assertNotIn('netstat.exe',text);self.assertNotIn('Get-NetTCPConnection',text)
    def test_exact_pins_and_consumed_prior(self):
        text=(HERE/'t5_dual_attest_rc2_candidate.py').read_text()
        self.assertIn('for prior in (V1_OUT, V2_OUT, RC1_OUT):',text)
        self.assertIn(m.GGUF_SHA,text)
        self.assertIn(m.EXE_SHA,text)
    def test_ports_not_prior(self):self.assertNotIn(m.PORT,(11434,12643,12644,12645))
    def test_model_context_bounds(self):self.assertEqual((m.CONTEXT,m.MAX_TOKENS),(256,32))
    def test_source_only_never_mutates_global_path(self):
        a=m.isolated_env(Path(r'D:\WORK\RESEARCH\TokenToModel-Lab\_tmp\isolated'))
        self.assertEqual(a['OLLAMA_NO_CLOUD'],'1')
        self.assertIsNot(a,__import__('os').environ)
    def test_parent_path_untouched(self):
        import os
        old=os.environ.get('PATH','')
        m.isolated_env(Path(r'D:\WORK\RESEARCH\TokenToModel-Lab\_tmp\isolated'))
        self.assertEqual(os.environ.get('PATH',''),old)
    def test_local_only_api_transport(self):
        src=(HERE/'t5_dual_attest_rc2_candidate.py').read_text()
        self.assertIn('urllib.request.ProxyHandler({})',src)
        self.assertIn('NON_LOCAL_API_CALL_DENIED',src)
    def test_oneshot_dir_separate(self):self.assertNotIn('v3rc1',str(m.OUT).lower())
    def test_source_defines_claim_and_result(self):
        src=(HERE/'t5_dual_attest_rc2_candidate.py').read_text()
        self.assertIn('"CLAIM.json"',src);self.assertIn('"RESULT.json"',src)
        self.assertIn('new_dir(OUT)',src)
    def test_static_ast_main_does_not_execute(self):
        tree=ast.parse((HERE/'t5_dual_attest_rc2_candidate.py').read_text())
        main=next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='main')
        calls=[node.func.id for node in ast.walk(main) if isinstance(node,ast.Call) and isinstance(node.func,ast.Name)]
        self.assertNotIn('execute',calls);self.assertNotIn('source_pins',calls)
    def test_iphelper_only_native_no_network(self):
        src=(HERE/'t5_native_tcp.py').read_text()
        self.assertNotIn('urllib.request',src);self.assertNotIn('subprocess.',src)
        self.assertIn('GetExtendedTcpTable',src)
    def test_no_science_change(self):
        src=(HERE/'t5_dual_attest_rc2_candidate.py').read_text()
        self.assertIn('FAIL_7_OF_8_PRESERVED',src)
        self.assertNotIn('lineage.md',src)
    def test_native_snapshot_single_pid_identity_query(self):
        def fake(af):return table(packet4()) if af==n.AF_INET else table()
        seen=[]
        x=m.tcp_table_observation(m.PORT,native_fn=fake,identity_fn=lambda pid:(seen.append(pid) or identity()))
        self.assertEqual((seen,len(x['rows']),len(x['processes'])),([PID],1,1))
    def test_native_snapshot_two_pids_skips_identity(self):
        def fake(af):return table(packet4(pid=PID),packet4(pid=99,remote_port=0)) if af==n.AF_INET else table()
        fn=Mock(side_effect=AssertionError('CIM_CALLED'))
        z=m.tcp_table_observation(m.PORT,native_fn=fake,identity_fn=fn)
        self.assertEqual(len(z['rows']),2);fn.assert_not_called()
    def test_native_snapshot_wrong_port_denied(self):
        with self.assertRaisesRegex(RuntimeError,'ONLY_PINNED'):
            m.tcp_table_observation(11434,native_fn=lambda af:table(),identity_fn=identity)
    def test_process_identity_invalid_pid_before_subprocess(self):
        with patch.object(m.subprocess,'run',side_effect=AssertionError('SPAWN')):
            with self.assertRaisesRegex(RuntimeError,'PID_INVALID'):m.process_identity(True)
    def test_native_recheck_requires_http(self):
        p=Proc()
        with patch.object(m,'readiness_sample',return_value={'decision':'HOLD_OWNER_CHANGED_AFTER_HTTP'}):
            with self.assertRaisesRegex(RuntimeError,'OWNERSHIP_RECHECK_HOLD'):
                m.assert_owned_listener(p,DATE)
    def test_process_identity_json_exact(self):
        encoded=[]
        def fake(cmd,**kwargs):
            encoded.append(cmd)
            return SimpleNamespace(returncode=0,stdout=json.dumps(identity()))
        with patch.object(m.subprocess,'run',side_effect=fake):
            result=m.process_identity(PID)
        self.assertEqual(result['pid'],PID)
        self.assertIn('-EncodedCommand',encoded[0])

class TestMockedCompatibilityPipeline(unittest.TestCase):
    """Entire dormant execute() path with fake subprocess, HTTP and hashes ONLY."""
    def simulate(self,*,create_rc=0,manifest=True,visible=True,done=True,tokens=8,tag=True):
        with fixture_dir() as d:
            out=d/'mock-single-attempt'
            events=[]
            proc=Proc(pid=PID)
            def fake_spawn(*args,**kwargs):
                events.append('serve');return proc
            def fake_run(*args,**kwargs):
                events.append('create');return SimpleNamespace(returncode=create_rc,stdout='mock',stderr='mock')
            def fake_api(url,body=None,timeout=4):
                if url.endswith('/api/tags'):
                    events.append('tags');return {'models':[{'name':m.MODEL}]} if visible else {'models':[]}
                if url.endswith('/api/generate'):
                    events.append('generate')
                    self.assertEqual(body['options']['num_ctx'],256)
                    self.assertEqual(body['options']['num_predict'],32)
                    self.assertEqual(body['stream'],False)
                    self.assertEqual(body['raw'],True)
                    return {'model':m.MODEL if tag else 'wrong','done':done,'eval_count':tokens,'response':'mock_text'}
                raise AssertionError('INVALID_ENDPOINT')
            hashes={m.GGUF.name:m.GGUF_SHA,m.EXE.name:m.EXE_SHA,m.ORIGINAL.name:m.ORIGINAL_SHA,m.V5B.name:m.V5B_SHA}
            def fake_sha(p):return hashes[Path(p).name]
            def fake_store(p):
                if Path(p).name=='models' and 'create' in events and create_rc==0 and manifest:
                    return {'manifests/registry.ollama.ai/library/ttm':{'sha256':'f'*64,'size':16}}
                return {}
            def fake_env(r):
                return {**__import__('os').environ,'OLLAMA_HOST':m.HOST,'OLLAMA_NO_CLOUD':'1',
                        'OLLAMA_MODELS':str(r/'models'),'OLLAMA_TMPDIR':str(r/'tmp'),
                        'TEMP':str(r/'tmp'),'TMP':str(r/'tmp'),'HOME':str(r/'home'),
                        'USERPROFILE':str(r/'home'),'APPDATA':str(r/'home'/'AppData'),
                        'LOCALAPPDATA':str(r/'home'/'LocalAppData'),'HOMEDRIVE':'D:',
                        'HOMEPATH':r'\WORK\RESEARCH','PATH':'C:\\Windows\\System32'}
            pins={'gguf':{'sha256':m.GGUF_SHA,'size':m.GGUF_BYTES,'path':str(m.GGUF)},
                  'original_fail':{'sha256':m.ORIGINAL_SHA},'v5b_fail':{'sha256':m.V5B_SHA},
                  'ollama_exe':{'sha256':m.EXE_SHA}}
            with patch.multiple(m,ROOT=d,OUT=out,SOURCE_ONLY_EXECUTION_LOCK=False), \
                 patch.object(m,'isolated_env',side_effect=fake_env), \
                 patch.object(m.subprocess,'CREATE_NEW_PROCESS_GROUP',0,create=True), \
                 patch.object(m.subprocess,'Popen',side_effect=fake_spawn), \
                 patch.object(m.subprocess,'run',side_effect=fake_run), \
                 patch.object(m,'sha256',side_effect=fake_sha), \
                 patch.object(m,'folder_snapshot',side_effect=fake_store), \
                 patch.object(m,'tcp_table_observation',return_value={'rows':[]}), \
                 patch.object(m,'observe_readiness_with_trace',return_value={'identity_creation_date':DATE,'ready':True}), \
                 patch.object(m,'assert_owned_listener',return_value={'decision':'READY_DUAL_ATTESTED_STATE_ZERO_UNKNOWN'}), \
                 patch.object(m,'api_json',side_effect=fake_api), \
                 patch.object(m,'stop_owned_server',return_value={'stop_status':'STOPPED_OWNED_TREE','taskkill_exit_code':0}):
                result=m.execute(pins)
            self.assertTrue((out/'CLAIM.json').is_file())
            self.assertTrue((out/'RESULT.json').is_file())
            self.assertEqual(json.loads((out/'RESULT.json').read_text())['status'],result['status'])
            self.assertFalse(result['science_train_or_test_executed'])
            self.assertEqual(result['frozen_parity'],'FAIL_7_OF_8_PRESERVED')
            return result,events

    def test_mock_pipeline_positive(self):
        r,e=self.simulate();self.assertEqual(r['status'],'PASS_COMPATIBILITY_ONLY_OLLAMA_IMPORT_AND_INFERENCE')
        self.assertEqual(e,['serve','create','tags','generate'])
    def test_mock_create_fails_no_generate(self):
        r,e=self.simulate(create_rc=1);self.assertIn('OLLAMA_CREATE_FAILED',r['failure']['message']);self.assertNotIn('generate',e)
    def test_mock_missing_manifest_no_generate(self):
        r,e=self.simulate(manifest=False);self.assertIn('CREATE_WITHOUT_PROJECT_LOCAL_MANIFEST',r['failure']['message']);self.assertNotIn('generate',e)
    def test_mock_tag_not_visible_no_generate(self):
        r,e=self.simulate(visible=False);self.assertIn('MODEL_TAG_NOT_VISIBLE',r['failure']['message']);self.assertNotIn('generate',e)
    def test_mock_no_done_fails(self):
        r,_=self.simulate(done=False);self.assertIn('GENERATION_NOT_CONFIRMED',r['failure']['message'])
    def test_mock_too_many_tokens_fails(self):
        r,_=self.simulate(tokens=33);self.assertIn('GENERATION_NOT_CONFIRMED',r['failure']['message'])
    def test_mock_zero_tokens_fails(self):
        r,_=self.simulate(tokens=0);self.assertIn('GENERATION_NOT_CONFIRMED',r['failure']['message'])
    def test_mock_wrong_model_fails(self):
        r,_=self.simulate(tag=False);self.assertIn('WRONG_RESPONSE_MODEL',r['failure']['message'])

if __name__=='__main__':
    unittest.main(verbosity=2)
